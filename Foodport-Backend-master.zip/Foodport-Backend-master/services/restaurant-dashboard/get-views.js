import { extend } from 'lodash';
import moment from 'moment';
import { Views, FoodCart, Sequelize } from '../../models';

const getViews = async ({ id, startDate, endDate }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }
    const views = await Views.findAll({
      where: {
        foodcartId: id,
        ...selector
      },
      attributes: [
        [Sequelize.fn('COUNT', 'Views.*'), 'total'],
        [Sequelize.col('Views.createdAt'), 'createdAt']
      ],
      include: [FoodCart],
      group: [Sequelize.fn('DAY', Sequelize.col('Views.createdAt'))]
    });

    const graphStat = [];
    const end = moment(endDate);

    for (const start = moment(startDate); start <= end; start.add(1, 'day')) {
      const currentView = views.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == start.format('DD/MM/YY')
      });

      let date = start.toDate();
      let count = 0;

      if (currentView) count = currentView.toJSON().total;
      graphStat.push({ date, count });
    }

    return { code: 200, data: graphStat }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getViews;
