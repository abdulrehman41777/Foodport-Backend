const uploadToS3 = async ({ files }) => {
  console.log('............', files);

}

export default uploadToS3;
