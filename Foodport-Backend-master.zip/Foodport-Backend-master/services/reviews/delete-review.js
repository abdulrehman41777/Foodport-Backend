import { Reviews, Sequelize, FoodCart } from '../../models';

const deleteReview = async ({ id }) => {
  try {
    let reviews = await Reviews.findByPk(id);
    if (!reviews) throw new Error ('Invalid id');

    const { FoodCartId } = reviews;
    await reviews.destroy();

    reviews = await Reviews.findOne({
      where: { FoodCartId },
      attributes: [
        [Sequelize.fn('COUNT', '*'), 'totalReviews'],
        [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('rating')), 1),'rating']
      ],
      raw: true
    });

    await FoodCart.update(
      {
        rating: reviews.rating,
        totalReviews: reviews.totalReviews,
      },
      { where: { id: FoodCartId } }
    );

    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteReview;
