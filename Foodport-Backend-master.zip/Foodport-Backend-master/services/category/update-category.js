import { Category } from '../../models';

const updateCategory = async ({ CategoryId, name }) => {
  try {

    const category = await Category.findOne({ where: { id: CategoryId } });
    if (!category) {
      throw Error(`Category not exist.`);
    }
    category.name = name;
    await category.save();

    return { code: 200, data: category }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateCategory;
