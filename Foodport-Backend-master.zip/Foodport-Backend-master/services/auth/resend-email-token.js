import moment from 'moment';

import { User, Token } from '../../models';
import { TOKEN_TYPE } from '../../constants/enums';
import { sendEmailVerifivation } from '../../utils/sendgrid';
import { digitId } from '../../utils/short-id';

const resendEmailToken = async ({ userId }) => {
  try {
    const user = await User.findByPk(userId);
    if (!user) throw new Error ('User not found');

    const emailToken = digitId(5);

    await Token.upsert(
      {
        token: emailToken,
        type: TOKEN_TYPE.EMAIL_VERIFICATION_TOKEN,
        UserId: user.id,
        expireAt: moment().add(3, 'minutes').toDate()
      },
      { fields: ['token', 'expireAt'] }
    );

    await sendEmailVerifivation({ to: user.email, data: { code: emailToken }});
    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default resendEmailToken;
