const model = (sequelize, DataType) => {
  const dealCuisineSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const DealCuisine = sequelize.define('DealCuisine', dealCuisineSchema);
  DealCuisine.associate = ({ Deal, Cuisine }) => {
    DealCuisine.belongsTo(Deal);
    DealCuisine.belongsTo(Cuisine);
  }

  return DealCuisine;
};

export default model;
