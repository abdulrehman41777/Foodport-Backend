import { FoodCart, RoleResource, Sequelize } from '../../models';

const deleteFoodcart = async ({ id }) => {
  try {
    await FoodCart.destroy({
      where: { id }
    });

    await RoleResource.destroy({
      where: {
        resourceId: id,
        resourceType: 'food-cart'
      }
    });

    await RoleResource.destroy({
      where: {
        resourceId: id,
        resourceType: 'restaurant'
      }
    });

    return { code: 200, message: 'Fooocart has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteFoodcart;
