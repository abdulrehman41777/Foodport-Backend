import { Deal } from '../../models';

const deleteDeal = async ({ id }) => {
  try {
    await Deal.destroy({
      where: { id }
    });

    return { code: 200, message: 'Deal has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteDeal;
