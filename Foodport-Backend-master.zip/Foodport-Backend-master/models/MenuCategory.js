const model = (sequelize, DataType) => {
  const menuCategorySchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const MenuCategory = sequelize.define('MenuCategory', menuCategorySchema);
  MenuCategory.associate = ({ Menu, Category }) => {
    MenuCategory.belongsTo(Menu);
    MenuCategory.belongsTo(Category);
  }

  return MenuCategory;
};

export default model;
