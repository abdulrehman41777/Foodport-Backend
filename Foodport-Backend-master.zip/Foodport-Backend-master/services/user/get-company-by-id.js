import { extend } from 'lodash';
import {
  Company,
} from '../../models';

const getCompanyById = async ({ companyId }) => {
  try {



    const company = await Company.findOne({
      where: { id: companyId }
    });

    return { code: 200, data: company }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCompanyById;
