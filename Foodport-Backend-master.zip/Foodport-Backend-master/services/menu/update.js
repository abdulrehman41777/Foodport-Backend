import { MenuCategory, MenuCuisine, Menu, sequelize, MenuImages, FoodCart, Sequelize, MenuDiscount } from '../../models';
import { MENU_IMAGES_TYPE, MENU_STATUS } from '../../constants/enums';

const updateMenu = async ({ menuId, categoryIds, cuisineIds, foodCartId, name, description, serveIn, price, discount, files }) => {
  let transaction;
  try {
    if (!foodCartId) throw new Error('Please enter foodCartId');

    transaction = await sequelize.transaction({ autoCommit: false });
    // UPDATE MENU
    await Menu.update(
      {
        name,
        description,
        price,
        serveIn,
        status: MENU_STATUS.ACTIVE
      },
      {
        transaction,
        where: { id: menuId }
      }
    );

    //Discount 
    if (discount) {
      await MenuDiscount.upsert(
        {
          MenuId: menuId,
          discount: discount,
          price: price,
          discounted_price: price - ((discount * price) / 100)
        },
        { transaction }
      );
    }

    // MENU IMAGES
    const { cover, images } = files;
    let menuImages = []
    if (images && images.length) {
      menuImages = images.map(({ key }) => ({
        name: key,
        MenuId: menuId,
        type: MENU_IMAGES_TYPE.IMAGE
      }));
    }

    // MENU COVER IMAGE
    if (cover && cover.length) {
      const image = cover.pop();
      menuImages.push({
        name: image.key,
        MenuId: menuId,
        type: MENU_IMAGES_TYPE.COVER
      });
    }

    if (menuImages.length) {
      await MenuImages.destroy({
        transaction,
        where: { MenuId: menuId }
      });
      await MenuImages.bulkCreate(menuImages, { transaction });
    }

    // MENU CATEGORIES
    if (categoryIds) {
      categoryIds = categoryIds.split(',');
      const menuCategories = categoryIds.map((id) => ({
        MenuId: menuId,
        CategoryId: id
      }));

      if (menuCategories && menuCategories.length) {
        await MenuCategory.destroy({
          transaction,
          where: { MenuId: menuId }
        });

        await MenuCategory.bulkCreate(menuCategories, { transaction });
      }
    }


    // MENU MenuCuisine
    if (cuisineIds) {
      cuisineIds = cuisineIds.split(',');
      const menuCuisines = cuisineIds.map((id) => ({
        MenuId: menuId,
        CuisinesId: id
      }));

      if (menuCuisines && menuCuisines.length) {
        await MenuCuisine.destroy({
          transaction,
          where: { MenuId: menuId }
        });

        await MenuCuisine.bulkCreate(menuCuisines, { transaction });
      }
    }

    await transaction.commit();
    transaction = null;

    // TOTAL MANU AND SUM OF ITS PRICE
    const menuStats = await Menu.findOne({
      where: {
        FoodCartId: foodCartId
      },
      attributes: [
        [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('price')), 1), 'menuWorth']
      ],
      raw: true
    });

    // UPDATE MENU WORTH IN FOODCART
    await FoodCart.update(
      { menuWorth: menuStats.menuWorth },
      {
        transaction,
        where: { id: foodCartId }
      }
    );

    return { code: 201 };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default updateMenu;
