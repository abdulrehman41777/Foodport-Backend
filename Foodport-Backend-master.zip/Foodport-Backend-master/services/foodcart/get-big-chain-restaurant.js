import { google } from '../../config/google';
const axios = require('axios');

const getBigChainRestaurant = async ({ latlng, radius, pageToken, keyword, minPrice = 0, maxPrice = 4 }) => {
  //console.log('asdasd', google.maps.places.RankBy.DISTANCE);
  try {

    var name = '';
    if (keyword) {
      name = `&name='${keyword}'`;
    }

    var pageT = '';
    if (pageToken) {
      pageT = `&pagetoken=${pageToken}`;
    }
    var miles = (1609.344 * radius);
    var url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${latlng}&rankby=distance&distance=${miles}&type=restaurant&keyword=restaurant&minprice=${minPrice}&maxprice=${maxPrice}${name}&key=AIzaSyCFpmRrgll23eF9QoiDUOVypqtTQks-zzo${pageT}`;
    console.log(url);
    const response = await axios.get(url)
      .then(({ data }) => data);


    // const selector = {};
    // if (keyword) {
    //   selector.keyword = keyword;
    // }

    // if (pageToken) {
    //   selector.pagetoken = pageToken;
    // }

    // const response = await google.placesNearby({
    //   params: {
    //     //opennow: true,
    //     location: latlng,
    //     radius: (1609.344 * radius),
    //     type: 'restaurant',
    //     minprice: minPrice,
    //     maxprice: maxPrice,
    //     ...selector
    //   }
    // })
    //   .then(({ data }) => data);

    const count = Object.keys(response.results).length;
    return { count: count, code: 200, data: response }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getBigChainRestaurant;
