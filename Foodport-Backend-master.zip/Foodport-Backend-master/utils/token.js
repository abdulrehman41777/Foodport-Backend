import jwt from 'jsonwebtoken';
import moment from 'moment';

export const getAuthToken = ({ userId, expireAt = moment().add(1, 'week') }) => {
  return jwt.sign(
    { userId, expireAt },
    process.env.JWT_SECRET
  );
}

export const getUserInviteToken = ({ userId, expireAt = moment().add(1, 'day') }) => {
  return jwt.sign(
    { userId, expireAt },
    process.env.JWT_SECRET
  );
}


export const verifyInviteToken = ({ token }) => {
  return jwt.verify(
    token,
    process.env.JWT_SECRET
  );
}

export const destroyJWTToken = ({ token }) => {
  return jwt.destroy(
    token,
    process.env.JWT_SECRET
  );
}