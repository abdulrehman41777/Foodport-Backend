import dotenv from 'dotenv';
dotenv.config({ path: `./environments/.env.${process.env.NODE_ENV}` });
