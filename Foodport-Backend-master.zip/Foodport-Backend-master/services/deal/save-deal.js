import { Deal, DealMenu, DealCategory, DealCuisine, DealImages, sequelize, FoodCart, Sequelize, DealDiscount } from '../../models';
import { DEAL_IMAGES_TYPE, DEAL_STATUS } from '../../constants/enums';

const saveDeal = async ({ menus, categoryIds, cuisineIds, foodCartId, name, description, serveIn, price, discount, files }) => {
  let transaction;
  try {
    if (!foodCartId) throw new Error('Please enter foodCartId');
    if (!menus) throw new Error('Please select Menus');
    if (!categoryIds) throw new Error('Please select Category');
    if (!cuisineIds) throw new Error('Please select Cuisine');
    const menusObj = JSON.parse("[" + menus + "]");
    categoryIds = categoryIds.split(',');
    cuisineIds = cuisineIds.split(',');
    transaction = await sequelize.transaction({ autoCommit: false });
    const deal = await Deal.create(
      {
        name,
        description,
        price,
        serveIn,
        FoodCartId: foodCartId,
        status: DEAL_STATUS.ACTIVE
      },
      { transaction }
    );

    //Discount 
    if (discount) {
      await DealDiscount.create(
        {
          DealId: deal.id,
          discount: discount,
          price: price,
          discounted_price: price - ((discount * price) / 100)
        },
        { transaction }
      );
    }

    const { cover: [cover], images } = files;
    const dealImages = images.map(({ key }) => ({
      name: key,
      DealId: deal.id,
      type: DEAL_IMAGES_TYPE.IMAGE
    }));

    dealImages.push({
      name: cover.key,
      DealId: deal.id,
      type: DEAL_IMAGES_TYPE.COVER
    });

    await DealImages.bulkCreate(dealImages, { transaction });

    const dealMenus = menusObj.map((obj) => ({
      DealId: deal.id,
      MenuId: obj.id,
      quantity: obj.quantity,
    }));

    await DealMenu.bulkCreate(dealMenus, { transaction });
    ///DealMenu

    ///DealCategory
    const dealCategories = categoryIds.map((id) => ({
      DealId: deal.id,
      CategorydealId: id
    }));

    await DealCategory.bulkCreate(dealCategories, { transaction });
    ///DealCategory

    //DealCuisine
    const dealCuisines = cuisineIds.map((id) => ({
      DealId: deal.id,
      CuisineId: id
    }));

    await DealCuisine.bulkCreate(dealCuisines, { transaction });
    //DealCuisine

    await transaction.commit();
    transaction = null;

    // TOTAL MANU AND SUM OF ITS PRICE
    // const dealStats = await Deal.findOne({
    //   where: {
    //     FoodCartId: foodCartId
    //   },
    //   attributes: [
    //     [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('price')), 1), 'dealWorth']
    //   ],
    //   raw: true
    // });

    // UPDATE MENU WORTH IN FOODCART
    // await FoodCart.update(
    //   { dealWorth: dealStats.dealWorth },
    //   {
    //     transaction,
    //     where: { id: foodCartId }
    //   }
    // );

    return { code: 201, data: deal };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default saveDeal;
