import bodyParser from 'body-parser';
import swaggerUi from 'swagger-ui-express';
import cors from 'cors';

import swaggerDocs from '../../docs/swagger.info';

const middlewares = (app) => {
  app.use('/api/v1/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));
  //app.use(bodyParser.urlencoded());
  //app.use(bodyParser.json());
  // app.use(bodyParser.urlencoded({
  //   extended: true
  // }));
  app.use(bodyParser.json());
  // parse requests of content-type - application/x-www-form-urlencoded
  app.use(bodyParser.urlencoded({ extended: true }));

  app.options('*', cors());
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
  });
}

export default middlewares;
