import authenticate from '../middlewares/routeMiddlewares/auth';

import auth from './auth';
import reviews from './reviews';
import foodcart from './foodcart';
import cuisine from './cuisine';
import category from './category';
import categorydeal from './categorydeal';
import menu from './menu';
import searchMenu from './searchmenu';
import dashboard from './dashboard';
import restaurantDashboard from './dashboard-restaurant';
import others from './others';
import user from './user';
import deal from './deal';

const appRoutes = (app) => {
  app.use('/api/v1/auth', auth);
  app.use('/api/v1/reviews', authenticate, reviews);
  app.use('/api/v1/foodcart', foodcart);
  app.use('/api/v1/cuisine', cuisine);
  app.use('/api/v1/category', category);
  app.use('/api/v1/categorydeal', categorydeal);
  app.use('/api/v1/menu', menu);
  app.use('/api/v1/searchmenu', searchMenu);
  app.use('/api/v1/dashboard', authenticate, dashboard);
  app.use('/api/v1/restaurant-dashboard', authenticate, restaurantDashboard);
  app.use('/api/v1/utls', others);
  app.use('/api/v1/user', user);
  app.use('/api/v1/deal', deal);

  app.use('/', (req, res) => {
    res.send('food cart api server');
  });
}

export default appRoutes;
