import express from 'express';
import { getCuisines, addCuisine, updateCuisines, deleteCuisine } from '../services/cuisine';
import authenticate from '../middlewares/routeMiddlewares/auth';


const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/cuisine:
 *   get:
 *     tags:
 *     - Cuisine
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: foodcartId
 *         in: query
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getCuisines({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/cuisine:
 *   post:
 *     tags:
 *     - Cuisine
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               foodCartId:
 *                 type: string
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/', authenticate, (req, res) => {
  addCuisine({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/cuisine:
 *   put:
 *     tags:
 *     - Cuisine
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               CuisineId:
 *                 type: string
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/', authenticate, (req, res) => {
  updateCuisines({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/cuisine/{id}:
 *   delete:
 *     tags:
 *     - Cuisine
 *     description: Delete Cuisine by Cuisine ID
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', authenticate, (req, res) => {
  deleteCuisine({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});



export default routers;
