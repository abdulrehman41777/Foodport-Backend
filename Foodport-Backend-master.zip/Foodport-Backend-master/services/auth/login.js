import moment from 'moment';

import { User, Token, Sequelize, Role, RoleResource, Grants } from '../../models';
import { comparePassword } from '../../utils/hash';
import { TOKEN_TYPE, USER_STATUS } from '../../constants/enums';
import { getAuthToken } from '../../utils/token';

const login = async ({ email, password }) => {
  try {
    const user = await User.findOne({
      where: { email, status: USER_STATUS.ACTIVE },
      include: [
        {
          model: Role,
          include: [
            {
              model: RoleResource,
              include: [Grants]
            }
          ]
        }
      ]
    });

    if (!user) throw new Error('Email does not exist OR Your acount is not activated yet.');

    const isAuthenticated = await comparePassword({
      hashPassword: user.password,
      planPassword: password
    });

    if (!isAuthenticated) throw new Error('Incorrect email or password.');

    const tokenExpireAt = moment().add(1, 'week');

    const authToken = getAuthToken({
      userId: user.id,
      expireAt: tokenExpireAt
    });


    await Token.upsert(
      {
        UserId: user.id,
        type: TOKEN_TYPE.AUTH_TOKEN,
        token: authToken,
        expireAt: tokenExpireAt
      },
      { fields: ['token', 'expireAt'] }
    );

    delete user.password;

    return { user, authToken, code: 201 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default login;
