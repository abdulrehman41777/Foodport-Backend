
export const development = {
  username: 'root',
  password: '',
  database: 'food_db',
  host: 'localhost',//'127.0.0.1',
  dialect: 'mysql'
}

export const staging = {
  username: 'food_db',
  password: 'dMloOEFyFk4JOCi5',
  database: 'food_db',
  host: 'food-cart-staging.clt8eopwiya8.us-east-2.rds.amazonaws.com',
  dialect: 'mysql'
}
