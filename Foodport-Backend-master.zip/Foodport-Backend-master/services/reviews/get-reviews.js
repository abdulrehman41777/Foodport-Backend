import { Reviews, FoodCart, User } from '../../models';

const getReviewsListing = async ({ foodcartId }) => {
  try {
    const reviews = await Reviews.findAll({
      where: {
        FoodCartId: foodcartId,
        status: 0,
      },
      include: [
        {
          model: User,
          attributes: ['firstName', 'lastName']
        }
      ],
      limit: 6
    });

    const { totalReviews } = await FoodCart.findOne({
      where: {
        id: foodcartId,
      },
      attributes: ['totalReviews'],
      raw: true
    });

    return { code: 200, data: { reviews, totalReviews } }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getReviewsListing;
