import { FoodCart, sequelize, FoodCartImages, FoodCartCuisine, BusinessHours } from '../../models';
import { FOOD_CART_IMAGES_TYPE, FOOD_CART_STATUS } from '../../constants/enums';
import { foodcartSerial } from '../../utils/short-id';

const addFoodcart = async ({
  companyId,
  files,
  description,
  latlng,
  type,
  email,
  phone,
  city,
  name,
  cuisines,
  businessHours
}) => {
  let transaction;
  try {
    if (!cuisines) throw new Error('Please select Cusines');
    cuisines = JSON.parse(cuisines);

    if (!businessHours) throw new Error('Please add Business Hours');
    businessHours = JSON.parse(businessHours);

    transaction = await sequelize.transaction({ autoCommit: false });
    const { cover: [cover], images } = files;

    const foodcart = new FoodCart({
      CompanyId: companyId,
      name,
      type,
      description,
      email,
      phone,
      latlng,
      type,
      city,
      status: FOOD_CART_STATUS.ACTIVE,
    });
    await foodcart.save({ transaction });

    const serialNo = foodcartSerial(foodcart.id);
    await FoodCart.update(
      { serialNo },
      {
        where: { id: foodcart.id },
        transaction
      });

    const foodcartImages = images.map(({ key }) => ({
      name: key,
      FoodCartId: foodcart.id,
      type: FOOD_CART_IMAGES_TYPE.IMAGE
    }));

    foodcartImages.push({
      name: cover.key,
      FoodCartId: foodcart.id,
      type: FOOD_CART_IMAGES_TYPE.COVER
    });

    await FoodCartImages.bulkCreate(foodcartImages, { transaction });

    const foodcartCuisines = cuisines.map((id) => ({
      FoodCartId: foodcart.id,
      CuisineId: id
    }));
    await FoodCartCuisine.bulkCreate(foodcartCuisines, { transaction });

    const foodcartBusinessHours = businessHours.map(({ startTime, endTime, isActive, day }) => ({
      startTime,
      endTime,
      isActive,
      day,
      FoodCartId: foodcart.id
    }));
    await BusinessHours.bulkCreate(foodcartBusinessHours, { transaction });

    await transaction.commit();
    return { foodcart, code: 201 };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default addFoodcart;
