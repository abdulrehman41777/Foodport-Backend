const socket = io('http://localhost:3000');
socket.emit('VISIT_FOOD_CART_PAGE', { foodcartId: 3 });

socket.on('CHANGE_LAT_LNG', (data) => console.log('.........', data))