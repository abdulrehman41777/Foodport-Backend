import { MenuCategory, Menu, MenuCuisine, Cuisine, MenuImages, MenuDiscount } from '../../models';

const getMenu = async ({ id }) => {
  try {
    const menu = await Menu.findByPk(id, {
      include: [
        {
          model: MenuCuisine,
          include: [Cuisine]
        },
        { model: MenuCategory },
        { model: MenuImages },
        { model: MenuDiscount }
      ]
    });

    return { code: 200, data: menu };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getMenu;
