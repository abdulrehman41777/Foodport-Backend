import { FoodCartLike } from '../../models';

const makeAsLikeUnlike = async ({ userId, foodcartId }) => {
  try {
    const userLikeFoodcart = await FoodCartLike.findOne({
      where: {
        UserId: userId,
        FoodCartId: foodcartId
      }
    });

    if (userLikeFoodcart) {
      await userLikeFoodcart.destroy();
    }
    else {
      await new FoodCartLike({
        FoodCartId: foodcartId,
        UserId: userId
      })
        .save();
    }

    return { code: 200 }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default makeAsLikeUnlike;
