import { FoodCart } from '../../models';
import { getAddressByLatlng, getDistanceByLatlng } from '../../utils/geo-calculations';

const updateLatlng = async ({ foodcartId, latlng, io }) => {
  try {


    const address = await getAddressByLatlng({ latlng });
    const { results } = address;
    const [addressComponents] = results;

    const city = addressComponents.address_components.find(({ types }) => {
      return types.some(x => x == 'administrative_area_level_2');
    });

    await FoodCart.update(
      { city: city.long_name, latlng },
      { where: { id: foodcartId } }
    );

    io
      .in(`FOOD_CART_MAP_VISITORS_${foodcartId}`)
      .emit('CHANGE_LAT_LNG', { latlng });

    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateLatlng;
