import { MenuCategory, MenuCuisine, Menu, sequelize, MenuImages, FoodCart, Sequelize, MenuDiscount } from '../../models';
import { MENU_IMAGES_TYPE, MENU_STATUS } from '../../constants/enums';

const saveMenu = async ({ categoryIds, cuisineIds, foodCartId, name, description, serveIn, price, discount, files }) => {
  let transaction;
  try {
    //categoryIds = JSON.parse(categoryIds);
    if (!foodCartId) throw new Error('Please enter foodCartId');
    if (!categoryIds) throw new Error('Please select Category');
    if (!cuisineIds) throw new Error('Please select Cuisine');
    categoryIds = categoryIds.split(',');
    cuisineIds = cuisineIds.split(',');
    //cuisineIds = JSON.parse(cuisineIds);
    transaction = await sequelize.transaction({ autoCommit: false });
    const menu = await Menu.create(
      {
        name,
        description,
        price,
        serveIn,
        FoodCartId: foodCartId,
        status: MENU_STATUS.ACTIVE
      },
      { transaction }
    );


    //Discount 
    if (discount) {
      await MenuDiscount.create(
        {
          MenuId: menu.id,
          discount: discount,
          price: price,
          discounted_price: price - ((discount * price) / 100)
        },
        { transaction }
      );
    }

    const { cover: [cover], images } = files;
    const menuImages = images.map(({ key }) => ({
      name: key,
      MenuId: menu.id,
      type: MENU_IMAGES_TYPE.IMAGE
    }));

    menuImages.push({
      name: cover.key,
      MenuId: menu.id,
      type: MENU_IMAGES_TYPE.COVER
    });

    await MenuImages.bulkCreate(menuImages, { transaction });

    const menuCategories = categoryIds.map((id) => ({
      MenuId: menu.id,
      CategoryId: id
    }));

    await MenuCategory.bulkCreate(menuCategories, { transaction });


    //DealCuisine
    const menuCuisines = cuisineIds.map((id) => ({
      MenuId: menu.id,
      CuisineId: id
    }));

    await MenuCuisine.bulkCreate(menuCuisines, { transaction });
    //DealCuisine


    await transaction.commit();
    transaction = null;

    // TOTAL MANU AND SUM OF ITS PRICE
    const menuStats = await Menu.findOne({
      where: {
        FoodCartId: foodCartId
      },
      attributes: [
        [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('price')), 1), 'menuWorth']
      ],
      raw: true
    });

    // UPDATE MENU WORTH IN FOODCART
    await FoodCart.update(
      { menuWorth: menuStats.menuWorth },
      {
        transaction,
        where: { id: foodCartId }
      }
    );

    return { code: 201, data: menu };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default saveMenu;
