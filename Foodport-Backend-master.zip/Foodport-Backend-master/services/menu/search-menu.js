import { extend } from 'lodash';
import { MenuCategory, Menu, MenuCuisine, Cuisine, Sequelize, MenuImages, Category } from '../../models';

const searchMenu = async ({ serveIn, cuisineId }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (serveIn) {
      extend(selector, { serveIn });
    }

    if (cuisineId) {
      extend(selector, { '$MenuCuisines.CuisineId$': { [Sequelize.Op.in]: JSON.parse(cuisineId) } });
    }

    const menu_rows = await Menu.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: MenuCuisine
        },
        { model: MenuImages }
      ]
      //offset: skip ? Number(skip) : null,
      // limit: limit ? Number(limit) : null
    });
    let madeArr = menu_rows.rows;//Object.entries(menu_rows)
    let menu_ids = madeArr.map(a => a.id);

    const selector2 = {};
    extend(selector2, { '$MenuCategories.MenuId$': { [Sequelize.Op.in]: menu_ids } });
    const cat_rows = await Category.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector2,
      include: [
        {
          model: MenuCategory
        }
      ]
      //offset: skip ? Number(skip) : null,
      // limit: limit ? Number(limit) : null
    });
    const res_data = { "menus": menu_rows, "cats": cat_rows }
    return { code: 200, data: res_data };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default searchMenu;
