import fs from 'fs';
import path from 'path';
import Sequelize from 'sequelize';
import signale from 'signale';
import * as config from '../config/db.config.js';

const basename = path.basename(__filename);
const { username, password, database, host, dialect } = config.development  //[process.env.NODE_ENV];
const db = {};

const sequelize = new Sequelize(database, username, password, {
  host,
  dialect,
  define: { timestamps: true },
  logging: (msg) => signale.info(msg)
});

// fs
//   .readdirSync(__dirname)
//   .filter(file => {
//     return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
//   })
//   .forEach(file => {
//     const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
//     db[model.name] = model;
//   });

// Object.keys(db).forEach(modelName => {
//   if (db[modelName].associate) {
//     db[modelName].associate(db);
//   }
// });

db.sequelize = sequelize;
db.Sequelize = Sequelize;

export default db;
