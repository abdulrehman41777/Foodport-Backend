import { BUSINESS_TYPE, FOOD_CART_STATUS, FOOD_CART_ONLINE } from '../constants/enums';

const model = (sequelize, DataType) => {
  const foodCartSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    serialNo: {
      type: DataType.STRING,
      allowNull: true
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    },
    description: {
      type: DataType.STRING,
      allowNull: true,
    },
    email: {
      type: DataType.STRING,
      isEmail: true,
      allowNull: true,
    },
    phone: {
      type: DataType.STRING,
      allowNull: true,
    },
    imageUrl: {
      type: DataType.STRING,
      allowNull: true,
    },
    placeId: {
      type: DataType.STRING,
      allowNull: true,
    },
    latlng: {
      type: DataType.STRING,
      allowNull: true,
    },
    type: {
      type: DataType.ENUM,
      values: [
        BUSINESS_TYPE.FOOD_CART,
        BUSINESS_TYPE.RESTAURANT,
        BUSINESS_TYPE.BIG_CHAIN_RESTAURANT
      ],
      allowNull: false
    },
    city: {
      type: DataType.STRING
    },
    rating: {
      type: DataType.FLOAT,
      default: 0
    },
    totalReviews: {
      type: DataType.INTEGER(11),
      default: 0
    },
    menuWorth: {
      type: DataType.DECIMAL,
      default: 0
    },
    views: {
      type: DataType.INTEGER(11),
      default: 0
    },
    address: {
      type: DataType.STRING,
      allowNull: true
    },
    status: {
      type: DataType.INTEGER(1),
      allowNull: false,
      default: FOOD_CART_STATUS.ACTIVE
    },
    isOnline: {
      type: DataType.BOOLEAN,
      allowNull: true,
      default: FOOD_CART_ONLINE.OFFLINE
    }
  }


  const FoodCart = sequelize.define('FoodCart', foodCartSchema);

  FoodCart.associate = ({ Menu, Deal, Company, Reviews, BusinessHours, FoodCartCuisine, Category, Categorydeal, FoodCartImages, Views }) => {
    FoodCart.belongsTo(Company);
    FoodCart.hasMany(Menu, { onDelete: 'cascade' });
    FoodCart.hasMany(Deal, { onDelete: 'cascade' });
    FoodCart.hasMany(Reviews, { onDelete: 'cascade' });
    FoodCart.hasMany(Views, { onDelete: 'cascade' });
    FoodCart.hasMany(BusinessHours, { onDelete: 'cascade' });
    FoodCart.hasMany(FoodCartCuisine, { onDelete: 'cascade' });
    FoodCart.hasMany(Category, { onDelete: 'cascade' });
    FoodCart.hasMany(Categorydeal, { onDelete: 'cascade' });
    FoodCart.hasMany(FoodCartImages, { onDelete: 'cascade' });
  }

  return FoodCart;
};

export default model;
