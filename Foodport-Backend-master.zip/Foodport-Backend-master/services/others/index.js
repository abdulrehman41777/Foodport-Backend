export { default as uploadToS3 } from './uploadToS3';
