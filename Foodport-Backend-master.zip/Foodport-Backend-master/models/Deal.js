import { DEAL_STATUS } from '../constants/enums';
const model = (sequelize, DataType) => {
  const dealSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    },
    description: {
      type: DataType.STRING,
      allowNull: false,
    },
    price: {
      type: DataType.DECIMAL,
      allowNull: false
    },
    serveIn: {
      type: DataType.ENUM,
      values: ['break-fast', 'lunch', 'dinner'],
      allowNull: false
    },
    status: {
      type: DataType.INTEGER(1),
      allowNull: false,
      default: DEAL_STATUS.ACTIVE
    }
  }


  const Deal = sequelize.define('Deal', dealSchema);
  Deal.associate = ({ FoodCart, DealCuisine, DealCategory, DealMenu, DealImages, DealDiscount }) => {
    Deal.belongsTo(FoodCart);
    Deal.hasMany(DealCuisine, { onDelete: 'cascade' });
    Deal.hasMany(DealMenu, { onDelete: 'cascade' });
    Deal.hasMany(DealImages, { onDelete: 'cascade' });
    Deal.hasOne(DealDiscount, { onDelete: 'cascade' });
    Deal.hasMany(DealCategory, { onDelete: 'cascade' });
  }

  return Deal;
};

export default model;
