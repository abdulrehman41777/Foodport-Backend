import { Reviews, Sequelize, FoodCart } from '../../models';

const submitReview = async ({ userId, rating, comments, foodCartId }) => {
  try {
    const review = await Reviews.create(
      {
        UserId: userId,
        rating,
        comments,
        FoodCartId: foodCartId
      }
    );

    const reviews = await Reviews.findOne({
      where: {
        FoodCartId: foodCartId
      },
      attributes: [
        [Sequelize.fn('COUNT', '*'), 'totalReviews'],
        [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('rating')), 1),'rating']
      ],
      raw: true
    });

    await FoodCart.update(
      {
        totalReviews: reviews.totalReviews,
        rating: reviews.rating
      },
      { where: { id: foodCartId } }
    );

    return { review, code: 201 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default submitReview;
