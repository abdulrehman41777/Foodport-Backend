import { extend } from 'lodash';
import { DealCategory, Deal, DealCuisine, Cuisine, Sequelize, DealImages, Categorydeal, DealDiscount } from '../../models';

const getFoodcartDeal = async ({ serveIn, cuisineId, skip, limit, foodcartId, keyword }) => {
  try {
    const selector = {};

    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }

    if (serveIn) {
      extend(selector, { '$DealCategories->Deal.serveIn$': serveIn });
    }

    if (cuisineId) {
      extend(selector, { '$DealCategories->Deal->DealCuisines.CuisineId$': cuisineId });
    }

    if (keyword) {
      extend(selector, {
        '$DealCategories->Deal.name$': { [Sequelize.Op.substring]: keyword }
      });
    }

    const deals = await Categorydeal.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: DealCategory,
          include: [
            {
              model: Deal,
              include: [
                DealCuisine,
                DealImages,
                DealDiscount
              ]
            }
          ]
        }
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });
    return { code: 200, data: deals };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcartDeal;
