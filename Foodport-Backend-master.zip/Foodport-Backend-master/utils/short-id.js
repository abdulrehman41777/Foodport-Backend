const alphabetId = (length) => {
  let rendom = '';
  const alphabets = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const alphabetsLength = alphabets.length;

  for (let i = 0; i < length; i++) {
    rendom += alphabets.charAt(Math.floor(Math.random() * alphabetsLength));
  }
  return rendom;
}

const digitId = (length) => {
  let rendom = '';
  const numbers = '0123456789';
  const numbersLength = numbers.length;

  for (let i = 0; i < length; i++) {
    rendom += numbers.charAt(Math.floor(Math.random() * numbersLength));
  }
  return rendom;
}

export { alphabetId };
export { digitId };

export const foodcartSerial = (id) => `${alphabetId(3)}-${digitId(3)}-${id}`;
