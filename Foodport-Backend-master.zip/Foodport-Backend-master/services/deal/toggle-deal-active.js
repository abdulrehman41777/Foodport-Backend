import { Deal } from '../../models';
import { MENU_STATUS } from '../../constants/enums';

const toggleDealActive = async ({ id }) => {
  try {
    const deal = await Deal.findByPk(id);
    if (!deal) throw new Error('Invalid id');

    deal.status = deal.status == MENU_STATUS.ACTIVE ? MENU_STATUS.DEAVTIVE : MENU_STATUS.ACTIVE;
    await deal.save();

    return { code: 200 }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default toggleDealActive;
