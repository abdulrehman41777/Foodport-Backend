const model = (sequelize, DataType) => {
  const cuisinesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const FoodCartCuisine = sequelize.define('FoodCartCuisine', cuisinesSchema);

  FoodCartCuisine.associate = ({ FoodCart, Cuisine }) => {
    FoodCartCuisine.belongsTo(FoodCart);
    FoodCartCuisine.belongsTo(Cuisine);
  }

  return FoodCartCuisine;
};

export default model;
