import moment from 'moment';

import { Token, Sequelize, User } from '../../models';
import { hashPassword } from '../../utils/hash';
import { TOKEN_TYPE } from '../../constants/enums';

const resetPassword = async ({ password, confirmPassword, userId, token }) => {
  try {

    if (password != confirmPassword) throw new Error('Password did not matched');

    const tokenData = await Token.findOne({
      where: {
        UserId: userId,
        token,
        type: TOKEN_TYPE.EMAIL_OTP
      }
    });

    if (!tokenData) throw new Error('Invalid Otp');


    await Token.destroy({
      where: {
        UserId: userId,
        token,
        type: TOKEN_TYPE.EMAIL_OTP
      }
    });

    await User.update(
      { password: await hashPassword({ password }) },
      { where: { id: userId } }
    );

    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default resetPassword;
