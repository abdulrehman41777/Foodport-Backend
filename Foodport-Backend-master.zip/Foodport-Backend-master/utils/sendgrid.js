import sendgrid from '../config/sendgrid';
const messageOptions = { from: process.env.SENDGRID_SENDER };

export const sendEmailVerifivation = ({ to, data }) => {
  const message = {
    ...messageOptions,
    to,
    subject: 'Please Verify your Email',
    templateId: 'd-f5c0bf513dce4b90b2157fcaa378ea66',
    dynamic_template_data: data
  }

  return sendgrid.send(message);
}

export const sendUserInvitation = ({ to, data }) => {
  const message = {
    ...messageOptions,
    to,
    subject: 'Invitation',
    templateId: 'd-a9768a899c5a47269dd912adf264ad5f',
    dynamic_template_data: data
  }

  return sendgrid.send(message);
}

export const sendResetPasswordOTP = ({ to, data }) => {
  const message = {
    ...messageOptions,
    to,
    subject: 'OTP For Forgot Password',
    templateId: 'd-c6e40426be9d4cb9a579f95031cb2c9f',
    dynamic_template_data: data
  }

  return sendgrid.send(message);
}
