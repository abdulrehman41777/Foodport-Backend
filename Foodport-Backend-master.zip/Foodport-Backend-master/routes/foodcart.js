import express from 'express';
import {
  addFoodcartSuperadmin,
  addFoodcart,
  getFoodcart,
  getFoodcartDetails,
  getFoodcartForAdmin,
  getFoodcartForSuperAdmin,
  deleteFoodcart,
  updateFoodcart,
  toggleFoodcartActive,
  updateLatlng,
  updateIsOnline,
  markAsLikeUnlike,
  bigChainRestaurant,
  bigChainRestaurantDetails,
  superadminUpdateFoodcart,
  superadminDeleteFoodcart
} from '../services/foodcart';
import authenticate from '../middlewares/routeMiddlewares/auth';
import { uploadRestaurantImage } from '../utils/multer';

import updateView from '../middlewares/routeMiddlewares/update-views';

const routers = express.Router();


/**
 * @swagger
 *
 * /api/v1/foodcart/superadmin:
 *   post:
 *     tags: 
 *     - Footcart
 *     description: Save FoodCart
 *     consumes:
 *      - multipart/form-data
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              cover:
 *                description: ''
 *                type: file
 *                format: binary
 *              images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 * 
 *              companyId:
 *                type: number
 *                required: true
 * 
 *              name:
 *                type: string
 *                required: true
 * 
 *              description:
 *                type: string
 *                required: true
 * 
 *              latlng:
 *                type: string
 *                required: true
 * 
 *              type:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - food-cart
 *                 - restaurant
 * 
 *              email:
 *                type: string
 *                required: true
 * 
 *              phone:
 *                type: string
 *                required: true
 * 
 *              city:
 *                type: string
 *                required: true
 * 
 *              businessHours:
 *                type: object
 *                required: true
 *                description: 'e.g. [{"startTime":"1","endTime":"2","isActive":"3","day":"sat"}]'
 * 
 *              cuisines:
 *                 type: string
 *                 required: true
 *                 description: 'e.g. ["1","2"]'
 * 
 * 
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/superadmin', [authenticate, uploadRestaurantImage], (req, res) => {
  const { user } = req;

  addFoodcartSuperadmin({
    ...req.body,
    authUserType: user.userType,
    files: req.files
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/foodcart:
 *   post:
 *     tags: 
 *     - Footcart
 *     description: Save FoodCart
 *     consumes:
 *      - multipart/form-data
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              cover:
 *                description: ''
 *                type: file
 *                format: binary
 *              images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 *
 *              name:
 *                type: string
 *                required: true
 *
 *              description:
 *                type: string
 *                required: true
 *
 *              latlng:
 *                type: string
 *                required: true
 *
 *              type:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - food-cart
 *                 - restaurant
 *
 *              email:
 *                type: string
 *                required: true
 *
 *              phone:
 *                type: string
 *                required: true
 *
 *              city:
 *                type: string
 *                required: true
 *
 *              businessHours:
 *                type: object
 *                required: true
 *                description: 'e.g. [{"startTime":"1","endTime":"2","isActive":"3","day":"sat"}]'
 *
 *              cuisines:
 *                 type: string
 *                 required: true
 *                 description: 'e.g. ["1","2"]'
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/', [authenticate, uploadRestaurantImage], (req, res) => {
  const { user } = req;

  addFoodcart({
    ...req.body,
    companyId: user.CompanyId,
    files: req.files
  })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/foodcart:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: radius
 *        in: query
 *        required: true
 *        description: ''
 * 
 *      - name: latlng
 *        in: query
 *        required: true
 *        description: ''
 * 
 *      - name: cuisineId
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: menuWorth
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: categoryId
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: skip
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: limit
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: type
 *        in: query
 *        required: false
 *        description: ''
 * 
 *     responses:
 *       200:
 *         description: null
 */


routers.get('/', (req, res) => {
  console.log({...req.query})
  getFoodcart({ ...req.query })
    .then((data) => {
      console.log(data)
      res.status(data.code).json(data)
    });
});

/**
 * @swagger
 *
 * /api/v1/foodcart/big-chain:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: radius
 *        in: query
 *        required: true
 *        description: ''
 * 
 *      - name: latlng
 *        in: query
 *        required: true
 *        description: ''
 * 
 *      - name: pageToken
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: keyword
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: minPrice
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: maxPrice
 *        in: query
 *        required: false
 *        description: ''
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/big-chain', (req, res) => {
  console.log(req.query)
  bigChainRestaurant({ ...req.query })
    .then((data) => {
      console.log(data) 
      res.status(data.code).json(data) 
});
});

/**
 * @swagger
 *
 * /api/v1/foodcart/admin:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: skip
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: limit
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: keyword
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: status
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: type
 *        in: query
 *        required: true
 *        description: 'food-cart or restaurant'
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/admin', authenticate, (req, res) => {
  const { user } = req;
  getFoodcartForAdmin({
    companyId: user.CompanyId,
    ...req.query
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/foodcart/superadmin:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: skip
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: limit
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: keyword
 *        in: query
 *        required: false
 *        description: ''
 * 
 *      - name: status
 *        in: query
 *        required: false
 *        description: ''
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/superadmin', authenticate, (req, res) => {
  const { user } = req;
  getFoodcartForSuperAdmin({
    authUserType: user.userType,
    ...req.query
  })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/foodcart/{id}:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 *        description: ''
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:id', updateView, (req, res) => {
  getFoodcartDetails({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/foodcart/{placeId}/big-chain:
 *   get:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: placeId
 *        in: path
 *        required: true
 *        description: ''
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:placeId/big-chain', (req, res) => {
  bigChainRestaurantDetails({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/foodcart/image/{foodcart_id}/{image_id}:
 *   delete:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: foodcart_id
 *        in: path
 *        required: true
 * 
 *      - name: image_id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/image/:foodcart_id/:image_id', (req, res) => {
  superadminDeleteFoodcart({
    ...req.params
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/foodcart/{id}:
 *   delete:
 *     tags: 
 *     - Footcart
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', authenticate, (req, res) => {
  deleteFoodcart({
    ...req.params
  })
    .then((data) => res.status(data.code).json(data));
});







/**
 * @swagger
 *
 * /api/v1/foodcart/{id}:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:foodcartId', [authenticate, uploadRestaurantImage], (req, res) => {
  updateFoodcart({
    ...req.params,
    ...req.body,
    files: req.files
  })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/foodcart/superadmin/{id}:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              cover:
 *                description: ''
 *                type: file
 *                format: binary
 *              images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 *
 *              companyId:
 *                type: number
 *                required: true
 *
 *              name:
 *                type: string
 *                required: true
 *
 *              description:
 *                type: string
 *                required: true
 *
 *              latlng:
 *                type: string
 *                required: true
 *
 *              type:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - food-cart
 *                 - restaurant
 *
 *              email:
 *                type: string
 *                required: true
 *
 *              phone:
 *                type: string
 *                required: true
 *
 *              city:
 *                type: string
 *                required: true
 *
 *              businessHours:
 *                type: object
 *                required: true
 *                description: 'e.g. [{"startTime":"1","endTime":"2","isActive":"3","day":"sat"}]'
 *
 *              cuisines:
 *                 type: string
 *                 required: true
 *                 description: 'e.g. ["1","2"]'
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/superadmin/:foodcartId', [authenticate, uploadRestaurantImage], (req, res) => {
  const { user } = req;
  superadminUpdateFoodcart({
    authUserType: user.userType,
    ...req.params,
    ...req.body,
    files: req.files
  })
    .then((data) => res.status(data.code).json(data));
});




/**
 * @swagger
 *
 * /api/v1/foodcart/{id}/toggle-active:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:id/toggle-active', authenticate, (req, res) => {
  toggleFoodcartActive({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/foodcart/{id}/mark-as-like-unlike:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:foodcartId/mark-as-like-unlike', authenticate, (req, res) => {
  const { user } = req;
  markAsLikeUnlike({ userId: user.id, ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/foodcart/{id}/latlng:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             latlng:
 *               type: string
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:foodcartId/latlng', authenticate, (req, res) => {
  const io = req.app.get('io');
  updateLatlng({
    ...req.params,
    ...req.body,
    io
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/foodcart/{id}/isOnline:
 *   put:
 *     tags: 
 *     - Footcart
 *     description: Update Foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             isOnline:
 *               type: integer
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:foodcartId/isOnline', authenticate, (req, res) => {
  // const io = req.app.get('io');
  updateIsOnline({
    ...req.params,
    ...req.body,
    // io
  })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
