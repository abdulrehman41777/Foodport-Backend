import moment from 'moment';

import { Token, Sequelize, User } from '../../models';
import { TOKEN_TYPE } from '../../constants/enums';

const verifyEmailOtp = async ({ userId, token }) => {
  try {

    if (!token) throw new Error('Token is Required');
    const tokenData = await Token.findOne({
      where: {
        UserId: userId,
        token,
        type: TOKEN_TYPE.EMAIL_OTP,
        expireAt: {
          [Sequelize.Op.gte]: moment().toDate()
        }
      }
    });

    if (!tokenData) throw new Error('Token Has Been Expired');

    // await User.update(
    //   { emailVerified: true },
    //   { where: { id: userId } }
    // );

    return { code: 200, data: { userId: userId, token: token } };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default verifyEmailOtp;
