import getDistance from 'geolib/es/getDistance';
import { google } from '../config/google';

export const getAddressByLatlng = ({ latlng }) => {
  return google.geocode({
    params: { latlng }
  })
    .then(({ data }) =>{
      console.log("data geo location",data)
     data
    });
}

export const getDistanceByLatlng = ({ latA, lngA, latB, lngB }) => {
  return getDistance(
    { latitude: latA, longitude: lngA },
    { latitude: latB, longitude: lngB },
  );
}
