export { default as saveCategorydeal } from './save-category';
export { default as getCategorydeal } from './get-category';
export { default as updateCategorydeal } from './update-categorydeal';
export { default as deleteCategorydeal } from './delete-categorydeal';
