import express from 'express';
import { searchMenu } from '../services/menu';
import authenticate from '../middlewares/routeMiddlewares/auth';
import { uploadMenuImage } from '../utils/multer';

const routers = express.Router();

/**
 * @swagger
 *
 * /api/v1/searchmenu:
 *   get:
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: serveIn
 *        in: query
 * 
 *      - name: cuisineId
 *        in: query
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  //console.log('sas');
  searchMenu({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
