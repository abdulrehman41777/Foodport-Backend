import { Categorydeal } from '../../models';

const updateCategorydeal = async ({ categorydealId, name }) => {
  try {

    const categorydeal = await Categorydeal.findOne({ where: { id: categorydealId } });
    if (!categorydeal) {
      throw Error(`Categorydeal not exist.`);
    }
    categorydeal.name = name;
    await categorydeal.save();

    return { code: 200, data: categorydeal }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateCategorydeal;




