import { User } from '../../models';
import { S3 } from '../../config/aws';

const deleteUserImage = async ({ user_id }) => {
  try {
    await User.update({ imageUrl: null }, {
      where: { id: user_id }
    });

    //console.log(S3);

    return { code: 200, message: 'User image has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteUserImage;
