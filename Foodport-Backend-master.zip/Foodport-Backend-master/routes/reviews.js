import express from 'express';
import { submitReview, getReviews, deleteReview, blockReview, getAllReviews } from '../services/reviews';

const routers = express.Router();

/**
 * @swagger
 *
 * /api/v1/reviews:
 *   post:
 *     tags:
 *     - Reviews
 *     description: Submit Reviews
 *     produces:
 *       - application/json
 *     security:
 *      - bearerAuth: [] 
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             rating:
 *               type: integer
 *               required: true
 *       
 *             comments:
 *               type: string
 *               required: true
 *       
 *             foodCartId:
 *               type: integer
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/').post((req, res) => {
  const { user } = req;

  submitReview({ ...req.body, userId: user.id })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/reviews/all:
 *   get:
 *     tags:
 *     - Reviews
 *     produces:
 *       - application/json
 *     security:
 *      - bearerAuth: []
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/all', (req, res) => {
  const { user } = req;
  getAllReviews({
    authUserType: user.userType
  })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/reviews:
 *   get:
 *     tags:
 *     - Reviews
 *     produces:
 *       - application/json
 *     security:
 *      - bearerAuth: []
 *     parameters:
 *      - name: foodcartId
 *        in: query
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getReviews({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/reviews/{id}:
 *   delete:
 *     tags:
 *     - Reviews
 *     produces:
 *       - application/json
 *     security:
 *      - bearerAuth: []
 *     parameters:
 *      - name: id
 *        in: path
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', (req, res) => {
  deleteReview({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/reviews/block/{id}:
 *   delete:
 *     tags:
 *     - Reviews
 *     produces:
 *       - application/json
 *     security:
 *      - bearerAuth: []
 *     parameters:
 *      - name: id
 *        in: path
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/block/:id', (req, res) => {
  blockReview({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
