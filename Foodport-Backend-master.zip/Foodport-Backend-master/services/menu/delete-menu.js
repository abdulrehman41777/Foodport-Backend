import { Menu } from '../../models';

const deleteMenu = async ({ id }) => {
  try {
    await Menu.destroy({
      where: { id }
    });

    return { code: 200, message: 'Menu has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteMenu;
