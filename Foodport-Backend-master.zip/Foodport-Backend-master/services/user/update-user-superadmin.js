import { extend } from 'lodash';
import { User, Sequelize } from '../../models';
import { hashPassword } from '../../utils/hash';
import { USER_TYPE } from '../../constants/enums';

const updateUserSuperadmin = async ({ authUserType, userId, file, firstName, lastName, phoneNumber, address, email, password }) => {

  try {


    if (authUserType != USER_TYPE.SUPERADMIN) {
      return { error: 'Only super admin can access this end point.', code: 400 };
    }


    const data = {
      firstName,
      lastName,
      phoneNumber,
      address
    }


    if (email) {
      const user_exist = await User.findOne({
        where: {
          email: email,
          id: {
            [Sequelize.Op.ne]: userId
          }
        }
      });
      if (user_exist) {
        return { code: 200, message: 'Email address already in use!' }
      }
      extend(data, {
        email
      });
    }

    if (file) {
      extend(data, { imageUrl: file.key });
    }

    if (password && password != null && password != 'null') {
      const securedPassword = await hashPassword({ password });
      extend(data, { password: securedPassword });
    }

    await User.update(
      { ...data },
      { where: { id: userId } }
    );

    return { code: 200, message: 'User has been updated successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateUserSuperadmin;
