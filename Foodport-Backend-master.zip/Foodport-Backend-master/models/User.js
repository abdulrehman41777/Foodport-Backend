const model = (sequelize, DataType) => {
  const userSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    firstName: {
      type: DataType.STRING(30),
      allowNull: false,
    },
    lastName: {
      type: DataType.STRING(30),
      allowNull: false,
    },
    phoneNumber: {
      type: DataType.STRING(50),
      allowNull: true,
    },
    email: {
      type: DataType.STRING(50),
      allowNull: false,
      validate: {
        isEmail: {
          args: true,
          msg: 'Email addess incorrect.'
        },
      },
      unique: {
        args: true,
        msg: 'Email address already in use!'
      }
    },
    emailVerified: {
      type: DataType.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    imageUrl: {
      type: DataType.STRING,
      allowNull: true,
    },
    password: {
      type: DataType.STRING(150),
      allowNull: true,
    },
    profileId: {
      type: DataType.STRING(200),
      allowNull: true,
    },
    accessToken: {
      type: DataType.TEXT,
      allowNull: true,
    },
    dateOfBirth: {
      type: DataType.DATEONLY,
      allowNull: true,
    },
    address: {
      type: DataType.STRING(300)
    },
    userType: {
      type: DataType.ENUM,
      values: ['client', 'business', 'child']
    },
    status: {
      type: DataType.INTEGER,
      allowNull: false,
      defaultValue: 1
    }
  }


  const User = sequelize.define('User', userSchema);

  User.associate = ({ Company, Token, Role }) => {
    User.hasMany(Token);
    User.belongsTo(Role, { onDelete: 'cascade' });
  }

  return User;
};

export default model;
