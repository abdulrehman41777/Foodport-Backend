const model = (sequelize, DataType) => {
  const dealDiscountSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    discount: {
      type: DataType.FLOAT,
      allowNull: true
    },
    price: {
      type: DataType.INTEGER(11),
      allowNull: true
    },
    discounted_price: {
      type: DataType.INTEGER(11),
      allowNull: true
    }
  }


  const DealDiscount = sequelize.define('DealDiscount', dealDiscountSchema);
  DealDiscount.associate = ({ Deal }) => {
    DealDiscount.belongsTo(Deal);
  }

  return DealDiscount;
};

export default model;
