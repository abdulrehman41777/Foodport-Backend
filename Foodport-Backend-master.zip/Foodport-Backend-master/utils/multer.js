import multer from 'multer';
import multerS3 from 'multer-s3';
//import { S3 } from '../config/aws';

const upload = multer({
  // storage: multerS3({
  //   s3: new S3(),
  //   bucket: process.env.BUCKET_NAME,
  //   acl: 'public-read',
  //   key: (req, file, cb) => {
  //     cb(null, file.originalname);
  //   }
  // })
});

export const uploadRestaurantImage = upload.fields([
  { name: 'cover', maxCount: 1 },
  { name: 'images' }
]);

export const uploadMenuImage = upload.fields([
  { name: 'cover', maxCount: 1 },
  { name: 'images' }
]);

export const uploadDealImage = upload.fields([
  { name: 'cover', maxCount: 1 },
  { name: 'images' }
]);

export default upload;
