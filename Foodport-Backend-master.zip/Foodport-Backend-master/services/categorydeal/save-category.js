import { Categorydeal } from '../../models';

const saveCategorydeal = async ({ foodCartId, name }) => {
  try {
    const category = await Categorydeal.create({
      name,
      FoodCartId: foodCartId
    });

    return { code: 201, data: category };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default saveCategorydeal;
