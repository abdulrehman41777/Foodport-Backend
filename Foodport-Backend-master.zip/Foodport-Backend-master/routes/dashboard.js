import express from 'express';
import { getViews, getReviewsState, getFoodcartListing } from '../services/dashboard';

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/dashboard/view-state:
 *   get:
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *      - name: startDate
 *        in: query
 *        required: false
 *
 *      - name: endDate
 *        in: query
 *        required: false
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/view-state', (req, res) => {
  const { user } = req;
  getViews({ companyId: user.CompanyId, ...req.query })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/dashboard/review-state:
 *   get:
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     parameters:
 *      - name: startDate
 *        in: query
 *        required: false
 * 
 *      - name: endDate
 *        in: query
 *        required: false
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/review-state', (req, res) => {
  const { user } = req;
  getReviewsState({ companyId: user.CompanyId, ...req.query })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/dashboard/foodcarts:
 *   get:
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/foodcarts', (req, res) => {
  const { user } = req;
  getFoodcartListing({ companyId: user.CompanyId })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
