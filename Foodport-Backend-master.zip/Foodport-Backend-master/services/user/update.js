import { extend } from 'lodash';
import { User } from '../../models';

const update = async ({ id, file, firstName, lastName, phoneNumber, address, email }) => {
  try {
    const data = {
      firstName,
      lastName,
      phoneNumber,
      email,
      address
    }

    if (file) {
      extend(data, { imageUrl: file.key });
    }

    await User.update(
      { ...data },
      { where: { id } }
    );

    return { code: 200, message: 'User has been updated successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default update;
