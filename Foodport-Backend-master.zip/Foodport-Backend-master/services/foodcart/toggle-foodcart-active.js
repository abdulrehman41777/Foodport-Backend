import { FoodCart } from '../../models';
import { FOOD_CART_STATUS } from '../../constants/enums';

const toggleFoodcartActive = async ({ id }) => {
  try {
    const foodcart = await FoodCart.findByPk(id);
    if (!foodcart) throw new Error ('Invalid id');

    foodcart.status = foodcart.status == FOOD_CART_STATUS.ACTIVE ? FOOD_CART_STATUS.DEAVTIVE : FOOD_CART_STATUS.ACTIVE;
    await foodcart.save();

    return { code: 200 }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default toggleFoodcartActive;
