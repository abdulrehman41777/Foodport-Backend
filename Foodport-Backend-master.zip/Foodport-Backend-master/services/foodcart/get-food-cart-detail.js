import {
  FoodCart,
  BusinessHours,
  FoodCartCuisine,
  Cuisine,
  Company,
  Reviews,
  User,
  Category,
  MenuCategory,
  Menu,
  MenuCuisine,
  FoodCartImages,
  FoodCartLike
} from '../../models';

const getFoodcartDetails = async ({ id }) => {
  try {
    FoodCart.hasMany(FoodCartLike, { foreignKey: 'FoodCartId' });
    FoodCartLike.belongsTo(FoodCart, { foreignKey: 'FoodCartId' });
    const foodcart = await FoodCart.findByPk(id, {
      include: [
        { model: BusinessHours },
        { model: FoodCartImages },
        { model: Company },
        {
          model: Reviews,
          include: [User],
          limit: 5
        },
        {
          model: FoodCartCuisine,
          include: [Cuisine]
        },
        {
          model: Category,
          include: [
            {
              model: MenuCategory,
              include: [
                {
                  model: Menu,
                  include: [MenuCuisine]
                }
              ]
            }
          ]
        },
        FoodCartLike
      ]
    });

    return { code: 200, data: foodcart }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcartDetails;
