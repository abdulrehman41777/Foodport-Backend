import { FoodCart } from '../../models';

const updateIsOnline = async ({ foodcartId, isOnline }) => {
  try {

    await FoodCart.update(
      { isOnline },
      { where: { id: foodcartId } }
    );

    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateIsOnline;
