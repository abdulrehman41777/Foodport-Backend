const model = (sequelize, DataType) => {
  const tokenSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    token: {
      type: DataType.STRING,
      allowNull: false
    },
    expireAt: {
      type: DataType.DATE,
      allowNull: true
    },
    type: {
      type: DataType.ENUM,
      values: [
        'auth-token',
        'email-verification-token',
        'email-otp'
      ],
      allowNull: false
    }
  }


  const Token = sequelize.define('Token', tokenSchema, {
    indexes: [
      {
        unique: true,
        fields: ['UserId', 'type']
      }
    ]
  });

  Token.associate = ({ User }) => {
    Token.belongsTo(User);
  };

  return Token;
};

export default model;
