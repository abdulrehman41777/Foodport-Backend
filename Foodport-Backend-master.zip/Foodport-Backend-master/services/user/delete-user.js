import { extend } from 'lodash';
import { User } from '../../models';
import { USER_STATUS } from '../../constants/enums';

const deleteUser = async ({ id }) => {
  try {
    const data = {
      status: USER_STATUS.INACTIVE
    }

    await User.update(
      { ...data },
      { where: { id } }
    );

    return { code: 200, message: 'User has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteUser;
