import { extend } from 'lodash';
import { DealMenu, DealCategory, Deal, Menu, DealCuisine, Cuisine, Sequelize, DealImages, Categorydeal, DealDiscount } from '../../models';

const getDeal = async ({ menuId, serveIn, cuisineId, categoryId, startDate, endDate, skip, limit, foodcartId, keyword }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (serveIn) {
      extend(selector, { serveIn });
    }

    if (menuId) {
      extend(selector, { '$DealMenu.MenuId$': menuId });
    }

    if (cuisineId) {
      extend(selector, { '$DealCuisines.CuisineId$': cuisineId });
    }

    if (categoryId) {
      extend(selector, { '$DealCategories.CategorydealId$': categoryId });
    }

    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }

    if (keyword) {
      extend(selector, {
        name: { [Sequelize.Op.substring]: keyword }
      });
    }

    const deals = await Deal.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: DealMenu,
          include: [Menu]
        },
        {
          model: DealCuisine,
          include: [Cuisine]
        },
        {
          model: DealCategory,
          include: [Categorydeal]
        },
        { model: DealImages },
        { model: DealDiscount }
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });

    return { code: 200, data: deals };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getDeal;
