import { GRANT_TYPES } from '../constants/enums';

export const up = async (queryInterface, Sequelize) => {
  const grantTypes = Object.values(GRANT_TYPES).map((grantType) => ({
    grantType,
    createdAt: new Date(),
    updatedAt: new Date()
  }));
  await queryInterface.bulkInsert('Grants', grantTypes, {
    updateOnDuplicate: ['grantType'],
    fields: ['grantType']
  });
}

export const down = async (queryInterface, Sequelize) => {
}
