import { extend } from 'lodash';
import moment from 'moment';

import { Reviews, FoodCart, Sequelize } from '../../models';

const getViews = async ({ id, startDate, endDate }) => {
  try {
    const selector = { FoodCartId: id };
    const dateRanges = [];

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }

    const foodcartStat = await Reviews.findAll({
      where: {
        ...selector
      },
      attributes: [
        [Sequelize.fn('COUNT', 'Reviews.*'), 'total'],
        [Sequelize.col('Reviews.createdAt'), 'createdAt']
      ],
      include: [FoodCart],
      group: [Sequelize.fn('DAY', Sequelize.col('Reviews.createdAt'))]
    });


    const graphStat = [];
    const end = moment(endDate);

    for (const start = moment(startDate); start <= end; start.add(1, 'day')) {
      const foodcart = foodcartStat.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == start.format('DD/MM/YY')
      });

      let date = start.toDate();
      let foodcartCount = 0;

      if (foodcart) {
        foodcartCount = foodcart.toJSON().total;
      }

      graphStat.push({ date, foodcartCount });
    }

    return { code: 200, data: graphStat }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getViews;
