import moment from 'moment';

import { User, Token, Sequelize, Role, RoleResource, Grants } from '../../models';
import { TOKEN_TYPE } from '../../constants/enums';

const authenticate = async (req, res, next) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const token = req.headers.authorization.replace('Bearer ', '');

  const userToken = await Token.findOne({
    where: {
      token,
      type: TOKEN_TYPE.AUTH_TOKEN,
      expireAt: {
        [Sequelize.Op.gt]: moment().toDate()
      }
    },
    include: [
      {
        model: User,
        include: [
          {
            model: Role,
            include: [
              {
                model: RoleResource,
                include: [Grants]
              }
            ]
          }
        ]
      }
    ]
  })

  if (!userToken) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  req.user = userToken.User;
  next();
}

export default authenticate;
