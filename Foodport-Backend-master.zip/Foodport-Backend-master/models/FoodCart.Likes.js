const model = (sequelize, DataType) => {
  const foodcartImagesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const FoodCartLike = sequelize.define(
    'FoodCartLike',
    foodcartImagesSchema,
    {
      indexes: [
        {
          unique: true,
          fields: ['UserId', 'FoodCartId']
        }
      ]
    });

  FoodCartLike.associate = ({ FoodCart, User }) => {
    FoodCartLike.belongsTo(FoodCart);
    FoodCartLike.belongsTo(User);
  }

  return FoodCartLike;
};

export default model;
