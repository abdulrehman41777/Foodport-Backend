import moment from 'moment';
import { User, Role, RoleResource, Grants, sequelize, Token, Sequelize } from '../../models';
import { TOKEN_TYPE, USER_STATUS } from '../../constants/enums';
import { getAuthToken, verifyInviteToken, destroyJWTToken } from '../../utils/token';
import { hashPassword } from '../../utils/hash';
const setPassword = async ({ token, password, confirmPassword }) => {
  try {


    if (password != confirmPassword) throw new Error('Password did not matched');

    if (!token) throw new Error('Token required');

    const userToken = verifyInviteToken({ token: token });

    const userId = userToken.userId

    const user = await User.findOne({
      where: { id: userId },
      include: [
        {
          model: Role,
          include: [
            {
              model: RoleResource,
              include: [Grants]
            }
          ]
        }
      ]
    });

    if (!user) throw new Error('Your token has been expired.');

    const tokenData = await Token.findOne({
      where: {
        token,
        UserId: user.id,
        type: TOKEN_TYPE.INVITE_TOKEN,
        expireAt: {
          [Sequelize.Op.gte]: moment().toDate()
        }
      }
    });

    if (!tokenData) throw new Error('Your token has been expired.');


    await User.update(
      { password: await hashPassword({ password }) },
      { where: { id: userId } }
    );

    const tokenExpireAt = moment().add(1, 'week');

    const authToken = getAuthToken({
      userId: user.id,
      expireAt: tokenExpireAt
    });


    await Token.upsert(
      {
        UserId: user.id,
        type: TOKEN_TYPE.AUTH_TOKEN,
        token: authToken,
        expireAt: tokenExpireAt
      },
      { fields: ['token', 'expireAt'] }
    );

    delete user.password;


    await Token.destroy({
      where: {
        token
      }
    });

    await User.update(
      {
        status: USER_STATUS.ACTIVE,
        emailVerified: 1

      },
      { where: { id: user.id } }
    );

    return { code: 200, user, authToken };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default setPassword;
