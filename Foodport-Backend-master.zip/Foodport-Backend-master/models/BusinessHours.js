const model = (sequelize, DataType) => {
  const businessHoursSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    startTime: {
      type: DataType.TIME,
      allowNull: false,
    },
    endTime: {
      type: DataType.TIME,
      allowNull: false,
    },
    isActive: {
      type: DataType.BOOLEAN,
      allowNull: false,
    },
    day: {
      type: DataType.ENUM,
      values: ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      allowNull: true,
    }
  }

  const BusinessHours = sequelize.define('BusinessHours', businessHoursSchema);
  BusinessHours.associate = ({ FoodCart }) => {
    BusinessHours.belongsTo(FoodCart);
  }

  return BusinessHours;
};

export default model;
