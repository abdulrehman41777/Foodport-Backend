import { User, Role, RoleResource, Grants, sequelize, FoodCart } from '../../models';
import { USER_STATUS } from '../../constants/enums';

const grantResource = async ({ foodcartId, userId, companyId }) => {
  let transaction;
  try {

    const user_exist = await User.findOne({
      where: { id: userId, CompanyId: companyId, status: USER_STATUS.ACTIVE }
    });

    if (!user_exist) {
      return { code: 400, message: 'User not exist or not active or not registered in this company.' }
    }

    const foodcart_exist = await FoodCart.findOne({
      where: { id: foodcartId, CompanyId: companyId }
    });

    if (!foodcart_exist) {
      return { code: 400, message: 'Foodcart Or Restaurant not exist or not registered in this company.' }
    }

    const RoleId = user_exist.RoleId;
    const resourceType = foodcart_exist.type;

    const resource_exist = await RoleResource.findOne({
      where: { RoleId, resourceType }
    });

    if (resource_exist) {
      return { code: 400, message: `This user already has resource type ${resourceType}` }
    }


    transaction = await sequelize.transaction({ autoCommit: false });

    //const role = await Role.create({ name: 'Assistant' }, { transaction });

    const resourcesData = {
      name: resourceType,
      resourceId: foodcartId,
      resourceType: resourceType,
      RoleId: RoleId
    };

    const resources = await RoleResource.create(resourcesData, { transaction });

    let grantsData = [
      ...grantsData,
      { grantType: `view-${resourceType}-dashboard`, RoleResourceId: resources.id },
      { grantType: `add-${resourceType}`, RoleResourceId: resources.id },
      { grantType: `edit-${resourceType}`, RoleResourceId: resources.id },
      { grantType: `delete-${resourceType}`, RoleResourceId: resources.id },
      { grantType: `view-${resourceType}`, RoleResourceId: resources.id }
    ]


    await Grants.bulkCreate(grantsData, { transaction });

    // const user = new User({
    //   firstName,
    //   lastName,
    //   email,
    //   status: USER_STATUS.INACTIVE,
    //   RoleId: role.id,
    //   CompanyId: companyId,
    //   userType: 'child'
    // });

    // await user.save({ transaction });

    // const token = getUsergrantResourceToken({ userId: user.id });
    // const redirectUrl = `${process.env.CLIENT_URL}/auth/grantResource/${token}`;

    // await sendUserInvitation({
    //   to: user.email,
    //   data: { redirectUrl }
    // });

    await transaction.commit();
    return {
      code: 200, message: `${resourceType} grant successfully`
    }
  }
  catch (error) {
    transaction && transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default grantResource;
