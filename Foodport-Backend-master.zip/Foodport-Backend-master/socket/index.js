const initializeSocket = (io) => {
  io.on('connection', (socket) => {
    socket.on('VISIT_FOOD_CART_PAGE', ({ foodcartId }) => {
      socket.join(`FOOD_CART_MAP_VISITORS_${foodcartId}`);
    });
  });
}

export default initializeSocket;
