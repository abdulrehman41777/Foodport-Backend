import { extend } from 'lodash';
import { MenuCategory, Menu, MenuCuisine, Cuisine, Sequelize, MenuImages, Category, MenuDiscount } from '../../models';

const getFoodcartMenu = async ({ serveIn, cuisineId, skip, limit, foodcartId, keyword }) => {
  try {
    const selector = {};

    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }

    if (serveIn) {
      extend(selector, { '$MenuCategories->Menu.serveIn$': serveIn });
    }

    if (cuisineId) {
      extend(selector, { '$MenuCategories->Menu->MenuCuisines.CuisineId$': cuisineId });
    }

    if (keyword) {
      extend(selector, {
        '$MenuCategories->Menu.name$': { [Sequelize.Op.substring]: keyword }
      });
    }

    const menus = await Category.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: MenuCategory,
          include: [
            {
              model: Menu,
              include: [
                MenuCuisine,
                MenuImages,
                MenuDiscount
              ]
            }
          ]
        }
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });
    return { code: 200, data: menus };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcartMenu;
