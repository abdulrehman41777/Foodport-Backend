import { extend } from 'lodash';
import { FoodCart, Sequelize, FoodCartImages, FoodCartCuisine, Cuisine, Company, BusinessHours } from '../../models';
import { USER_TYPE } from '../../constants/enums';

const getFoodcartForSuperAdmin = async ({ authUserType, skip, limit, keyword, status }) => {
  try {
    if (authUserType != USER_TYPE.SUPERADMIN) {
      return { error: 'Only super admin can access this end point.', code: 400 };
    }
    const selector = {};
    if (keyword) {
      selector[Sequelize.Op.or] = [
        { name: { [Sequelize.Op.substring]: keyword } },
        { serialNo: { [Sequelize.Op.substring]: keyword } }
      ];
    }

    if (status) {
      extend(selector, { status });
    }

    const data = await FoodCart.findAndCountAll({
      distinct: true,
      where: { ...selector },
      include: [
        {
          model: FoodCartCuisine,
          include: [Cuisine]
        },
        { model: Company },
        {
          model: BusinessHours,
          separate: true
        },
        {
          model: FoodCartImages,
          separate: true
        }
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });

    return { code: 200, data }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcartForSuperAdmin;
