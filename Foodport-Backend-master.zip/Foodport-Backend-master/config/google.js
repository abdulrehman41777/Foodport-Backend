import { Client } from '@googlemaps/google-maps-services-js';
import axios from 'axios';

export const google = new Client({
  axiosInstance: axios.create({
    params: { key: 'AIzaSyCFpmRrgll23eF9QoiDUOVypqtTQks-zzo' }
  })
});
