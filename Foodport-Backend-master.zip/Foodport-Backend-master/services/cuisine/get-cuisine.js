import { extend } from 'lodash';
import { Cuisine, FoodCartCuisine } from '../../models';

const getCuisines = async ({ foodcartId }) => {
  try {
    const selector = {};
    if (foodcartId) {
      extend(selector, { '$FoodCartCuisines.FoodCartId$': foodcartId });
    }
    const cuisines = await Cuisine.findAll({
      where: selector,
      include: [FoodCartCuisine],
      distinct: true,
    });
    return { code: 200, data: cuisines }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCuisines;
