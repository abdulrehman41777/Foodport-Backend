import { extend } from 'lodash';
import { Categorydeal } from '../../models';

const getCategorydeal = async ({ foodcartId }) => {
  try {
    const selector = {};
    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }
    const categories = await Categorydeal.findAll({
      where: selector
    });

    return { code: 201, data: categories };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCategorydeal;
