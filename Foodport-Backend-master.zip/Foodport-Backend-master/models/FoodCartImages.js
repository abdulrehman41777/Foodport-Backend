const model = (sequelize, DataType) => {
  const foodcartImagesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false
    },
    type: {
      type: DataType.INTEGER(1),
      allowNull: false,
    }
  }


  const FoodCartImages = sequelize.define('FoodCartImages', foodcartImagesSchema);
  FoodCartImages.associate = ({ FoodCart }) => {
    FoodCartImages.belongsTo(FoodCart);
  }

  return FoodCartImages;
};

export default model;
