import { FoodCartImages } from '../../models';
import { S3 } from '../../config/aws';

const deleteUserImage = async ({ foodcart_id, image_id }) => {
  try {
    await FoodCartImages.destroy({
      where: { id: image_id, FoodCartId: foodcart_id }
    });

    //console.log(S3);

    return { code: 200, message: 'Fooocart image has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteUserImage;
