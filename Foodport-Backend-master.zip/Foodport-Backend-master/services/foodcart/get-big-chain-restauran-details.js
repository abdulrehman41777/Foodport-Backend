import { google } from '../../config/google';

const getBigChainRestaurantDetails = async ({ placeId }) => {
  try {
    const response = await google.placeDetails({
      params: {
        place_id: placeId
      }
    })
      .then(({ data }) => data);
    return { code: 200, data: response }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getBigChainRestaurantDetails;
