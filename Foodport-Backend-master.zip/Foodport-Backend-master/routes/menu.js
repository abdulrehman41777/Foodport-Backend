import express from 'express';
import { saveMenu, getMenu, deleteMenu, updateMenu, getMenuById, toggleMenuActive, getFoodcartMenu, saveDiscount, getTopRatedMenu } from '../services/menu';
import authenticate from '../middlewares/routeMiddlewares/auth';
import { uploadMenuImage } from '../utils/multer';
const { body, check, validationResult } = require('express-validator');

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/menu:
 *   post:
 *     tags:
 *     - Menu
 *     consumes:
 *      - multipart/form-data
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *               cover:
 *                description: ''
 *                type: file
 *                format: binary
 *               images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 *      
 *               name:
 *                 type: string
 *                 required: true
 * 
 *               description:
 *                 type: string
 *                 required: true
 * 
 *               foodCartId:
 *                 type: number
 *                 required: true
 * 
 *               price:
 *                 type: number
 *                 required: true
 * 
 *               discount:
 *                 type: number
 *                 required: true
 * 
 *               categoryIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 *
 *               cuisineIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 * 
 *               serveIn:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - break-fast
 *                 - lunch
 *                 - dinner
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/',
  // check('name').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // check('description').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // check('foodCartId').isNumeric().withMessage('Value must be numeric').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // check('price').isNumeric().withMessage('Value must be numeric').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // check('categoryIds').isArray().withMessage('Value must be an array').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // check('cuisineIds').isArray().withMessage('Value must be an array').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // check('serveIn').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  [authenticate, uploadMenuImage], (req, res) => {

    // const errors = validationResult(req);
    // if (!errors.isEmpty()) {
    //   return res.status(400).json({ error: errors.array({ onlyFirstError: true }) });
    // }

    saveMenu({ ...req.body, files: req.files })
      .then((data) => res.status(data.code).json(data));
  });


/**
* @swagger
*
* /api/v1/menu/discount-create-update:
*   post:
*     tags:
*     - Menu
*     produces:
*       - application/json
*     security:
*       - bearerAuth: []
*     requestBody:
*       content:
*         application/json:
*           schema:
*             properties:
*               menus:
*                 type: array
*                 required: true
*                 items:
*                   type: object
*                   properties:
*                     id:
*                       type: integer
*                     price:
*                       type: integer
*                     discount:
*                       type: number
*                     
*
*     responses:
*       200:
*         description: null
*/

routers.post('/discount-create-update',
  [authenticate],
  (req, res) => {

    // const errors = validationResult(req);
    // if (!errors.isEmpty()) {
    //   return res.status(400).json({ error: errors.array({ onlyFirstError: true }) });
    // }

    saveDiscount({ ...req.body })
      .then((data) => res.status(data.code).json(data));
  });



/**
 * @swagger
 *
 * /api/v1/menu:
 *   get:
 *     tags:
 *     - Menu
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: cuisineId
 *        in: query
 *    
 *      - name: categoryId
 *        in: query
 * 
 *      - name: serveIn
 *        in: query
 * 
 *      - name: startDate
 *        in: query
 * 
 *      - name: endDate
 *        in: query
 * 
 *      - name: foodcartId
 *        in: query
 * 
 *      - name: skip
 *        in: query
 * 
 *      - name: limit
 *        in: query
 * 
 *      - name: keyword
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getMenu({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/menu/get_foodcart_menu:
 *   get:
 *     tags:
 *     - Menu
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: foodcartId
 *        in: query
 * 
 *      - name: serveIn
 *        in: query
 *
 *      - name: cuisineId
 *        in: query
 * 
 *      - name: skip
 *        in: query
 * 
 *      - name: limit
 *        in: query
 * 
 *      - name: keyword
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/get_foodcart_menu', (req, res) => {
  getFoodcartMenu({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/menu/top-rated:
 *   get:
 *     tags:
 *     - Menu
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: foodcartId
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/top-rated', (req, res) => {
  getTopRatedMenu({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/menu/{id}:
 *   delete:
 *     tags:
 *     - Menu
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', authenticate, (req, res) => {
  deleteMenu({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/menu/update:
 *   post:
 *     tags:
 *     - Menu
 *     consumes:
 *      - multipart/form-data
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *               cover:
 *                description: ''
 *                type: file
 *                format: binary
 *               images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 *
 *               menuId:
 *                 type: number
 *                 required: true
 * 
 *               name:
 *                 type: string
 *                 required: true
 *
 *               description:
 *                 type: string
 *                 required: true
 *
 *               foodCartId:
 *                 type: number
 *                 required: true
 *
 *               price:
 *                 type: number
 *                 required: true
 *
 *               discount:
 *                 type: number
 *                 required: true
 *
 *               categoryIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 *
 *               cuisineIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 *
 *               serveIn:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - break-fast
 *                 - lunch
 *                 - dinner
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/update', [authenticate, uploadMenuImage], (req, res) => {
  updateMenu({ ...req.body, files: req.files })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/menu/{id}/toggle-active:
 *   put:
 *     tags:
 *     - Menu
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:id/toggle-active', authenticate, (req, res) => {
  toggleMenuActive({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/menu/{id}:
 *   get:
 *     tags:
 *     - Menu
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:id', [authenticate], (req, res) => {
  getMenuById({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
