import moment from 'moment';

import { Token, Sequelize, User } from '../../models';
import { TOKEN_TYPE } from '../../constants/enums';

const verifyEmailToken = async ({ userId, token }) => {
  try {

    const tokenData = await Token.findOne({
      where: {
        token,
        UserId: userId,
        type: TOKEN_TYPE.EMAIL_VERIFICATION_TOKEN,
        expireAt: {
          [Sequelize.Op.gte]: moment().toDate()
        }
      }
    });

    if (!tokenData) throw new Error('Invalid token');

    await User.update(
      { emailVerified: true },
      { where: { id: userId } }
    );

    return { code: 200 };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default verifyEmailToken;
