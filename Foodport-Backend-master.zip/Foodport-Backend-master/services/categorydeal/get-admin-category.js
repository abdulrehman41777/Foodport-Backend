import { Categorydeal } from '../../models';

const getCategorydeal = async ({ category }) => {
  try {
    const categories = await Categorydeal.findAll({});

    return { code: 201, data: categories };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCategorydeal;
