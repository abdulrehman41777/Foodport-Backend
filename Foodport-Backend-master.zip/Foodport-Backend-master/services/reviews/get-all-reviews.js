import { Reviews, FoodCart, User } from '../../models';
import { USER_TYPE } from '../../constants/enums';

const getAllReviews = async ({ authUserType }) => {
  try {

    if (authUserType != USER_TYPE.SUPERADMIN) {
      return { error: 'Only super admin can access this end point.', code: 400 };
    }

    const data = await Reviews.findAndCountAll({
      include: [
        {
          model: User,
          attributes: ['firstName', 'lastName']
        }
      ],
      limit: 6
    });

    // const { totalReviews } = await FoodCart.findOne({
    //   where: {
    //     id: foodcartId,
    //   },
    //   attributes: ['totalReviews'],
    //   raw: true
    // });

    return { code: 200, data }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getAllReviews;
