import { extend } from 'lodash';
import { MenuCategory, Menu, MenuCuisine, Cuisine, Sequelize, MenuImages, Category, MenuDiscount } from '../../models';

const getTopRatedMenu = async ({ foodcartId }) => {
  try {
    const selector = {};
    const dateRanges = [];


    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }

    const menus = await Menu.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: MenuCuisine,
          include: [Cuisine]
        },
        {
          model: MenuCategory
        },
        {
          model: MenuImages
        },
        { model: MenuDiscount }
      ],
      limit: 5
    });

    return { code: 200, data: menus };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getTopRatedMenu;
