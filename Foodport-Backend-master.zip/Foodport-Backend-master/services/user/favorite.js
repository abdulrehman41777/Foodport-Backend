import { extend } from 'lodash';
import {
  FoodCart,
  BusinessHours,
  FoodCartCuisine,
  Cuisine,
  Company,
  Reviews,
  User,
  Category,
  MenuCategory,
  Menu,
  MenuCuisine,
  FoodCartImages,
  FoodCartLike
} from '../../models';

const favorite = async ({ userId }) => {
  try {
    const selector = {};
    if (userId) {
      extend(selector, { '$FoodCartLikes.UserId$': userId });
    }

    FoodCart.hasMany(FoodCartLike, { foreignKey: 'FoodCartId' });
    FoodCartLike.belongsTo(FoodCart, { foreignKey: 'FoodCartId' });
    const foodcart = await FoodCart.findAndCountAll({
      where: selector,
      include: [
        { model: BusinessHours },
        { model: FoodCartImages },
        { model: Company },
        {
          model: Reviews,
          include: [User],
          limit: 5
        },
        {
          model: FoodCartCuisine,
          include: [Cuisine]
        },
        {
          model: Category,
          include: [
            {
              model: MenuCategory,
              include: [
                {
                  model: Menu,
                  include: [MenuCuisine]
                }
              ]
            }
          ]
        },
        { model: FoodCartLike }
      ]
    });

    return { code: 200, data: foodcart }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default favorite;
