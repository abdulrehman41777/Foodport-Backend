import { extend } from 'lodash';
import { FoodCart, Sequelize, FoodCartImages } from '../../models';

const getFoodcartForAdmin = async ({ companyId, skip, limit, keyword, status, type }) => {
  try {
    const selector = { CompanyId: companyId };

    if (keyword) {
      selector[Sequelize.Op.or] = [
        { name: { [Sequelize.Op.substring]: keyword } },
        { serialNo: { [Sequelize.Op.substring]: keyword } }
      ];
    }


    if (status) {
      extend(selector, { status });
    }

    if (type) {
      extend(selector, { type });
    }

    const data = await FoodCart.findAndCountAll({
      distinct: true,
      where: { ...selector },
      include: [FoodCartImages],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });

    return { code: 200, data }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcartForAdmin;
