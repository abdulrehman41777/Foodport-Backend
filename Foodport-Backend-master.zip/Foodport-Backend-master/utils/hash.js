import bcrypt from 'bcrypt';

export const hashPassword = ({ password }) => {
  return bcrypt.hash(password, 10);
}

export const comparePassword = ({ hashPassword, planPassword }) => {
  return bcrypt.compare(planPassword, hashPassword);
}
console.log("hash")