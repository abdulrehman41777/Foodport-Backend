import express from 'express';
import { saveCategorydeal, getCategorydeal, updateCategorydeal, deleteCategorydeal } from '../services/categorydeal';

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/categorydeal:
 *   post:
 *     tags:
 *     - Categorydeal
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               foodCartId:
 *                 type: number
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/', (req, res) => {
  saveCategorydeal({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/categorydeal:
 *   get:
 *     tags:
 *     - Categorydeal
 *     produces:
 *       - application/json
 * 
 *     parameters:
 *       - name: foodcartId
 *         in: query
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getCategorydeal({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/categorydeal:
 *   put:
 *     tags:
 *     - Categorydeal
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               categorydealId:
 *                 type: string
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/', (req, res) => {
  updateCategorydeal({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/categorydeal/{id}:
 *   delete:
 *     tags:
 *     - Categorydeal
 *     description: Delete Categorydeal by Categorydeal ID
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', (req, res) => {
  deleteCategorydeal({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});


export default routers;
