import express from 'express';
import { uploadRestaurantImage } from '../utils/multer';
import { uploadToS3 } from '../services/others';

const routers = express.Router();

/**
 * @swagger
 *
 * /api/v1/menu:
 *   get:
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: cuisineId
 *        in: query
 *    
 *      - name: categoryId
 *        in: query
 * 
 *      - name: serveIn
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/upload', uploadRestaurantImage, (req, res) => {
  uploadToS3({
    ...req.body,
    files: req.files
  })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
