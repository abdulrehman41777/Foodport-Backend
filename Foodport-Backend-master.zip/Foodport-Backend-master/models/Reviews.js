const model = (sequelize, DataType) => {
  const reviewSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    rating: {
      type: DataType.FLOAT,
      allowNull: false,
    },
    status: {
      type: DataType.BOOLEAN,
      allowNull: false,
      defaultValue: true
    },
    comments: {
      type: DataType.STRING,
      allowNull: true,
    }
  }


  const Reviews = sequelize.define('Reviews', reviewSchema);
  Reviews.associate = ({ FoodCart, User }) => {
    Reviews.belongsTo(FoodCart);
    Reviews.belongsTo(User);
  }

  return Reviews;
};

export default model;
