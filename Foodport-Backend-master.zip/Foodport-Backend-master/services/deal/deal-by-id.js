import { DealCategory, Deal, DealCuisine, Cuisine, DealImages, DealDiscount } from '../../models';

const getDeal = async ({ id }) => {
  try {
    const deal = await Deal.findByPk(id, {
      include: [
        {
          model: DealCuisine,
          include: [Cuisine]
        },
        { model: DealCategory },
        { model: DealImages },
        { model: DealDiscount }
      ]
    });

    return { code: 200, data: deal };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getDeal;
