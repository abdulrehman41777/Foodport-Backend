import { MENU_STATUS } from '../constants/enums';
const model = (sequelize, DataType) => {
  const menuSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    },
    description: {
      type: DataType.STRING,
      allowNull: false,
    },
    price: {
      type: DataType.DECIMAL,
      allowNull: false
    },
    serveIn: {
      type: DataType.ENUM,
      values: ['break-fast', 'lunch', 'dinner'],
      allowNull: false
    },
    status: {
      type: DataType.INTEGER(1),
      allowNull: false,
      default: MENU_STATUS.ACTIVE
    }
  }


  const Menu = sequelize.define('Menu', menuSchema);
  Menu.associate = ({ FoodCart, MenuCuisine, MenuCategory, MenuImages, MenuDiscount }) => {
    Menu.belongsTo(FoodCart);
    Menu.hasMany(MenuCuisine, { onDelete: 'cascade' });
    Menu.hasMany(MenuCategory, { onDelete: 'cascade' });
    Menu.hasMany(MenuImages, { onDelete: 'cascade' });
    Menu.hasOne(MenuDiscount, { onDelete: 'cascade' });
  }

  return Menu;
};

export default model;
