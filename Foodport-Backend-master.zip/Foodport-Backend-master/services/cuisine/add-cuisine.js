import { Cuisine, FoodCartCuisine } from '../../models';

const addCuisines = async ({ foodCartId, name }) => {
  try {

    const cuisine = await Cuisine.create({ name });

    const foodCartCuisine = await FoodCartCuisine.create({ CuisineId: cuisine.id, FoodCartId: foodCartId });

    return { code: 200, data: cuisine }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default addCuisines;
