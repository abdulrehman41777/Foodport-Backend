import { extend } from 'lodash';
import moment from 'moment';
import { Views, FoodCart, Sequelize } from '../../models';

const getViews = async ({ companyId, startDate, endDate }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }
    const views = await Views.findAll({
      where: {
        '$FoodCart.CompanyId$': companyId
      },
      attributes: [
        [Sequelize.fn('COUNT', 'Views.*'), 'total'],
        [Sequelize.col('Views.createdAt'), 'createdAt']
      ],
      include: [FoodCart],
      group: [Sequelize.fn('DAY', Sequelize.col('Views.createdAt'))]
    });

    const graphStat = [];
    const end = moment(endDate);

    for (const start = moment(startDate); start <= end; start.add(1, 'day')) {
      const currentView = views.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == start.format('DD/MM/YY')
      });

      let date = start.format('DD/MM/YYYY');
      let count = 0;

      if (currentView) count = currentView.toJSON().total;
      graphStat.push({ date, count });
    }

    const currentDate = moment().format('DD/MM/YY');
    const todayViewRows = views.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == currentDate
    });
    let todayViews = 0;
    if (todayViewRows) todayViews = todayViewRows.toJSON().total;


    let lastDayDate = moment();
    lastDayDate = lastDayDate.add(-1, 'day');
    const lastDayViewRows = views.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == lastDayDate.format('DD/MM/YY')
    });
    let lastDayViews = 0;
    if (lastDayViewRows) lastDayViews = lastDayViewRows.toJSON().total;


    let lastWeekViews = 0;
    let lastWeekDate = moment();
    lastWeekDate = lastWeekDate.add(-7, 'day');
    const end_date = moment();
    for (const start_date = lastWeekDate; start_date <= end_date; start_date.add(1, 'day')) {
      const lastWeekViewRows = views.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == lastWeekDate.format('DD/MM/YY')
      });
      if (lastWeekViewRows) lastWeekViews += lastWeekViewRows.toJSON().total;
    }
    const states = [{ todayViews, lastDayViews, lastWeekViews }];

    return { code: 200, data: graphStat, states }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getViews;
