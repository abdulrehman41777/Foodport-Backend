import signale from 'signale';
import express from 'express';
import path from 'path';
import http from 'http';
import https from 'https';
import fs from 'fs';
import socketio from 'socket.io';
import initializeSocket from './socket';

const cors = require("cors");

import './environments';

//changes
//var key = fs.readFileSync('/etc/letsencrypt/live/foodport.us/privkey.pem');
//var cert = fs.readFileSync('/etc/letsencrypt/live/foodport.us/fullchain.pem');

const app = express();

var corsOptions = {
  origin: "http://localhost:4000"
};

app.use(cors(corsOptions));

// var key = fs.readFileSync('server.key');
// var cert = fs.readFileSync('server.cert');
// var options = {
//   key: key,
//   cert: cert
// };


//GOOGLE_MAP_KEY=AIzaSyAauJJEyM4gX9qRpGEx6ZyNXhK8SEA4NP8

// sIR gIVEN REACT_APP_GOOGLE_MAP_API_KEY=AIzaSyC-mxEG1ofmSnd8AfjkWrjHBLY-JsEDuFw
//chnages
//console.log(key);

//const app = express();


// const server = https.createServer(options, app);




// const io = socketio(server, {
//   cors: {
//     origin: process.env.SERVER_URL,
//     methods: ['GET', 'POST']
//   }
// });



 import appRoutes from './routes';
 import middlewares from './middlewares/appMiddlewares';

app.use(express.static(path.join(__dirname, 'public')));
 middlewares(app);
 appRoutes(app);




//initializeSocket(io);

//app.set('io', io);

// server.listen(3001, () =>
//   signale.success('Server is listening on port 3001'));
  

import db from "./models";
db.sequelize.sync({ force: true }).then(() => {
  console.log("Drop and re-sync db.");
});


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}..`));