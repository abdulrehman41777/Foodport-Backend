import { Reviews, FoodCart, Sequelize, User, FoodCartImages } from '../../models';
import { BUSINESS_TYPE } from '../../constants/enums';

const getFoodCartListing = async ({ companyId }) => {
  try {
    const foodcarts = await FoodCart.findAll({
      where: {
        CompanyId: companyId,
        type: BUSINESS_TYPE.FOOD_CART
      },
      include: [FoodCartImages],
      limit: 6
    });

    const restaurants = await FoodCart.findAll({
      where: {
        CompanyId: companyId,
        type: BUSINESS_TYPE.RESTAURANT
      },
      include: [FoodCartImages],
      limit: 6
    });

    const reviews = await Reviews.findAll({
      subQuery: false,
      where: {
        '$FoodCart.CompanyId$': companyId
      },
      include: [
        FoodCart,
        {
          model: User,
          attributes: ['firstName', 'lastName']
        }
      ],
      limit: 6
    });

    const { total } = await FoodCart.findOne({
      where: {
        CompanyId: companyId,
      },
      attributes: [
        [Sequelize.fn('SUM', Sequelize.col('FoodCart.totalReviews')), 'total']
      ],
      raw: true
    })
    
    return { code: 200, data: { foodcarts, restaurants, reviews, totalReviews: Number(total) } }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodCartListing;
