export const USER_TYPE = {
  SUPERADMIN: 'superadmin',
  CLIENT: 'client',
  BUSINESS: 'business',
  CHILD: 'child',
}

export const BUSINESS_TYPE = {
  FOOD_CART: 'food-cart',
  RESTAURANT: 'restaurant',
  BIG_CHAIN_RESTAURANT: 'big-chain-restaurant'
}

export const TOKEN_TYPE = {
  AUTH_TOKEN: 'auth-token',
  EMAIL_VERIFICATION_TOKEN: 'email-verification-token',
  EMAIL_OTP: 'email-otp',
  INVITE_TOKEN: 'invite-token'
}

export const PAGE_VIEWS_TYPE = {
  FOOD_CART_DETAIL: 1,
}

export const FOOD_CART_IMAGES_TYPE = {
  COVER: 1,
  IMAGE: 2
}

export const MENU_IMAGES_TYPE = {
  COVER: 1,
  IMAGE: 2
}

export const DEAL_IMAGES_TYPE = {
  COVER: 1,
  IMAGE: 2
}

export const MENU_STATUS = {
  ACTIVE: 1,
  DEAVTIVE: 2
}

export const DEAL_STATUS = {
  ACTIVE: 1,
  DEAVTIVE: 2
}


export const FOOD_CART_STATUS = {
  ACTIVE: 1,
  DEAVTIVE: 2
}


export const FOOD_CART_ONLINE = {
  OFFLINE: 0,
  ONLINE: 1

}

export const DEFAULT_ROLES = [
  'Admin',
  'Assistant'
]

export const USER_STATUS = {
  ACTIVE: 1,
  INACTIVE: 2
}
