import { Categorydeal, DealCategory } from '../../models';

const deleteCategorydeal = async ({ id }) => {
  try {
    await Categorydeal.destroy({
      where: { id }
    });

    await DealCategory.destroy({
      where: { CategorydealId: id }
    });

    return { code: 200, message: 'Categorydeal has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteCategorydeal;
