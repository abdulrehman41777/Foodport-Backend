const model = (sequelize, DataType) => {
  const viewsSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    page: {
      type: DataType.INTEGER(2),
      allowNull: false
    },
    ip: {
      type: DataType.STRING(20),
      allowNull: false
    },
    lastVisited: {
      type: DataType.DATE,
      allowNull: false
    },
    foodcartId: {
      type: DataType.INTEGER(11),
      allowNull: false
    }
  }

  const Views = sequelize.define('Views', viewsSchema);

  Views.associate = ({ FoodCart }) => {
    Views.belongsTo(FoodCart, {
      foreignKey: {
        fieldName: 'foodcartId',
        allowNull: false
      }
    });
  }
  return Views;
};

export default model;
