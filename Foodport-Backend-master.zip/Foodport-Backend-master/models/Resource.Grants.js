const model = (sequelize, DataType) => {
  const grantsSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    grantType: {
      type: DataType.ENUM,
      values: [
        'view-company-dashboard',
        'view-food-cart-dashboard',
        'view-food-cart',
        'add-food-cart',
        'edit-food-cart',
        'delete-food-cart',
        'view-restaurant-dashboard',
        'view-restaurant',
        'add-restaurant',
        'edit-restaurant',
        'delete-restaurant',
        'add-menu',
        'edit-menu',
        'delete-menu',
        'delete-reviews',
        'view-users',
        'invite-user',
        '*'
      ]
    }
  }

  const Grants = sequelize.define('Grants', grantsSchema);

  Grants.associate = ({ RoleResource }) => {
    Grants.belongsTo(RoleResource);
  }

  return Grants;
};

export default model;
