const model = (sequelize, DataType) => {
  const cuisinesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING(100),
      allowNull: false,
    }
  }


  const Cuisine = sequelize.define('Cuisine', cuisinesSchema);

  Cuisine.associate = ({ FoodCartCuisine, MenuCuisine, DealCuisine }) => {
    Cuisine.hasMany(FoodCartCuisine, { onDelete: 'cascade' });
    Cuisine.hasMany(MenuCuisine, { onDelete: 'cascade' });
    Cuisine.hasMany(DealCuisine, { onDelete: 'cascade' });
  }

  return Cuisine;
};

export default model;
