import { Cuisine, FoodCartCuisine } from '../../models';

const updateCuisines = async ({ CuisineId, name }) => {
  try {

    const cuisine = await Cuisine.findOne({ where: { id: CuisineId } });
    if (!cuisine) {
      throw Error(`Cuisine not exist.`);
    }
    cuisine.name = name;
    await cuisine.save();

    return { code: 200, data: cuisine }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default updateCuisines;
