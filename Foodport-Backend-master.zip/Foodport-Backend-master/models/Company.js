const model = (sequelize, DataType) => {
  const userSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    businessName: {
      type: DataType.STRING(100),
      allowNull: false,
      unique: {
        args: true,
        msg: 'Business name already in use!'
      }
    },
    registrationNumber: {
      type: DataType.STRING(50),
      allowNull: true
    }
  }


  const Company = sequelize.define('Company', userSchema);

  Company.associate = ({ User, FoodCart }) => {
    Company.hasMany(User);
    Company.hasMany(FoodCart);
  }

  return Company;
};

export default model;
