import { extend } from 'lodash';
import {
  Company,
} from '../../models';

const getCompany = async ({ userId }) => {
  try {

    const companies = await Company.findAndCountAll();

    return { code: 200, data: companies }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCompany;
