import { extend } from 'lodash';
import moment from 'moment';

import { User, Company, sequelize, Token } from '../../models';
import { hashPassword } from '../../utils/hash';
import { USER_TYPE, TOKEN_TYPE } from '../../constants/enums';
import { getAuthToken } from '../../utils/token';
import { sendEmailVerifivation } from '../../utils/sendgrid';
import { digitId } from '../../utils/short-id';

const signup = async ({
  firstName,
  lastName,
  businessName,
  email,
  phone,
  password,
  address,
  dob,
  userType
}) => {
  let transaction;
  try {
    const securedPassword = await hashPassword({ password });
    const userData = {
      firstName,
      lastName,
      email,
      phoneNumber: phone,
      password: securedPassword,
      userType
    };

    if (userType == USER_TYPE.CLIENT) {
      extend(userData, {
        address,
        dateOfBirth: dob
      });
    }

    // START TRANSACTION
    transaction = await sequelize.transaction({ autoCommit: false });

    if (userType == USER_TYPE.BUSINESS) {
      const company = await Company.create(
        { businessName },
        { transaction }
      );

      userData.CompanyId = company.id;
    }

    const user = await User.create(userData, { transaction });

    const tokenExpireAt = moment().add(1, 'week');
    const authToken = getAuthToken({
      userId: user.id,
      expireAt: tokenExpireAt
    });

    const emailToken = digitId(5);

    await Token.bulkCreate([
      {
        token: authToken,
        type: TOKEN_TYPE.AUTH_TOKEN,
        UserId: user.id,
        expireAt: tokenExpireAt
      },
      {
        token: emailToken,
        type: TOKEN_TYPE.EMAIL_VERIFICATION_TOKEN,
        UserId: user.id,
        expireAt: moment().add(3, 'minutes').toDate()
      }
    ],
      { transaction }
    );

    await sendEmailVerifivation({ to: email, data: { code: emailToken } });

    delete user.password;

    await transaction.commit();
    return { user, authToken, code: 201 };
  }
  catch (error) {
    if (transaction) await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default signup;
