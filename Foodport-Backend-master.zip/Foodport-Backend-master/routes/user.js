import express from 'express';
import upload from '../utils/multer';
import { updateUser, invite, inviteVerify, setPassword, favorite, grantResource, getBusinessUsers, getAllUsers, addUser, deleteUser, updateUserSuperadmin, getCompany, getCompanyById, deleteUserImage } from '../services/user';
import authenticate from '../middlewares/routeMiddlewares/auth';

const routers = express.Router();

/**
 * @swagger
 *
 * /api/v1/user/current:
 *   get:
 *     tags:
 *     - User
 *     description: get User Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/current', authenticate, (req, res) => {
  res.status(200).json(req.user);
});




/**
 * @swagger
 *
 * /api/v1/user/business:
 *   get:
 *     tags:
 *     - User
 *     description: get User Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 * 
 *     parameters:
 *      - name: skip
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: limit
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: keyword
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: status
 *        in: query
 *        required: false
 *        description: ''
 *
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/business', authenticate, (req, res) => {
  const { user } = req;
  getBusinessUsers({
    authUserType: user.userType
  })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/user/all:
 *   get:
 *     tags:
 *     - User
 *     description: get User Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 * 
 *     parameters:
 *      - name: skip
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: limit
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: keyword
 *        in: query
 *        required: false
 *        description: ''
 *
 *      - name: status
 *        in: query
 *        required: false
 *        description: ''
 *
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/all', authenticate, (req, res) => {
  const { user } = req;
  getAllUsers({
    authUserType: user.userType
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/user/add:
 *   post:
 *     tags:
 *     - User
 *     description: Login to the application
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *             image:
 *                description: ''
 *                type: file
 *                format: binary
 *             firstName:
 *               type: string
 *               required: true
 *
 *             lastName:
 *               type: string
 *               required: true
 *
 *             businessName:
 *               description: Bussiness name if user signup as business.
 *               type: string
 *               required: true
 *
 *             email:
 *               description: User valid email address to login.
 *               type: string
 *
 *             phone:
 *               required: false
 *               type: string
 *
 *             password:
 *               description: password to login.
 *               type: string
 *
 *             address:
 *               description: Postcode | City
 *               type: string
 *
 *             dob:
 *               description: Date of birth
 *               type: string
 *               format: date-time
 *
 *             userType:
 *               type: string
 *               enum:
 *                - client
 *                - business
 * 
 *     responses:
 *       200:
 *         description: login
 */

routers.route('/add').post(authenticate, upload.single('image'), (req, res) => {
  const authUserType = req.user.userType;
  addUser({
    file: req.file,
    authUserType,
    ...req.body
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/user/invite:
 *   post:
 *     tags:
 *     - User
 *     description: Login to the application
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             firstName:
 *               type: string
 *               required: true
 *            
 *             lastName:
 *               type: string
 *               required: true
 * 
 *             email:
 *               type: string
 *               required: true
 * 
 *             foodcartId:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/invite').post(authenticate, (req, res) => {
  const companyId = req.user.CompanyId;
  invite({ companyId, ...req.body })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/user/grant-resource:
 *   post:
 *     tags:
 *     - User
 *     description: Login to the application
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 * 
 *             foodcartId:
 *               type: string
 *               required: true
 * 
 *             userId:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/grant-resource').post(authenticate, (req, res) => {
  const companyId = req.user.CompanyId;
  grantResource({ companyId, ...req.body })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/user/current:
 *   put:
 *     tags:
 *     - User
 *     description: Update User
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *             image:
 *                description: ''
 *                type: file
 *                format: binary
 *             firstName:
 *               type: string
 *               required: true
 *
 *             lastName:
 *               type: string
 *               required: true
 *
 *             email:
 *               type: string
 *               required: true
 * 
 *             phoneNumber:
 *               type: string
 *               required: true
 * 
 *             address:
 *               type: string
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/current', authenticate, upload.single('image'), (req, res) => {
  const { user } = req;
  updateUser({
    ...req.body,
    file: req.file,
    id: user.id
  })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/user/superadmin:
 *   put:
 *     tags:
 *     - User
 *     description: Update User by superadmin
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *             image:
 *                description: ''
 *                type: file
 *                format: binary
 *             userId:
 *               type: string
 *               required: true
 * 
 *             firstName:
 *               type: string
 *               required: true
 *
 *             lastName:
 *               type: string
 *               required: true
 *
 *             email:
 *               type: string
 *               required: true
 * 
 *             phoneNumber:
 *               type: string
 *               required: true
 * 
 *             address:
 *               type: string
 *               required: true
 * 
 *             password:
 *               type: string
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/superadmin', authenticate, upload.single('image'), (req, res) => {
  const { user } = req;
  updateUserSuperadmin({
    ...req.body,
    file: req.file,
    authUserType: user.userType
  })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/user/invite-verify:
 *   post:
 *     tags:
 *     - User
 *     description: Verify invited user
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             token:
 *               type: string
 *               required: true
 *            
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/invite-verify').post((req, res) => {
  inviteVerify({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/user/set-password:
 *   post:
 *     tags:
 *     - User
 *     description: Set Password
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             token:
 *               type: string
 *               required: true
 *            
 *             password:
 *               type: string
 *               required: true
 * 
 *             confirmPassword:
 *               type: string
 *               required: true
 * 
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/set-password').post((req, res) => {
  setPassword({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/user/favorite-foodcart:
 *   get:
 *     tags:
 *     - User
 *     description: get user favorite foodcart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/favorite-foodcart', authenticate, (req, res) => {
  const { user } = req;
  favorite({ userId: user.id })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/user/{id}:
 *   delete:
 *     tags:
 *     - User
 *     description: Delete user
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', authenticate, (req, res) => {
  deleteUser({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});




/**
 * @swagger
 *
 * /api/v1/user/company:
 *   get:
 *     tags:
 *     - User
 *     description: get user company
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/company', authenticate, (req, res) => {
  const { user } = req;
  getCompany({ roleId: user.RoleId })
    .then((data) => res.status(data.code).json(data));
});



/**
 * @swagger
 *
 * /api/v1/user/company_by_id:
 *   get:
 *     tags:
 *     - User
 *     description: get user company
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/company_by_id', authenticate, (req, res) => {
  const { user } = req;
  getCompanyById({ companyId: user.CompanyId })
    .then((data) => res.status(data.code).json(data));
});




/**
 * @swagger
 *
 * /api/v1/user/image/{user_id}:
 *   delete:
 *     tags: 
 *     - User
 *     description: Delete User Image
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: user_id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/image/:user_id', authenticate, (req, res) => {
  deleteUserImage({
    ...req.params
  })
    .then((data) => res.status(data.code).json(data));
});




export default routers;
