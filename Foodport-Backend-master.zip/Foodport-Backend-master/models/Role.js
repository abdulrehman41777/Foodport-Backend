const model = (sequelize, DataType) => {
  const roleSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    }
  }


  const Role = sequelize.define('Role', roleSchema);

  Role.associate = ({ RoleResource }) => {
    Role.hasMany(RoleResource, { onDelete: 'cascade' });
  }

  return Role;
};

export default model;
