import { extend } from 'lodash';

import { FoodCart, Sequelize, BusinessHours, FoodCartCuisine, Cuisine, sequelize, Company, FoodCartImages, FoodCartLike } from '../../models';
import { getAddressByLatlng, getDistanceByLatlng } from '../../utils/geo-calculations';
import { FOOD_CART_STATUS, FOOD_CART_ONLINE } from '../../constants/enums';

const getFoodcart = async ({ latlng, radius, skip, limit, type, cuisineId, menuWorth, categoryId }) => {
  try {
    const address = await getAddressByLatlng({ latlng });
    console.log("address",address)
    const { results } = address;
    const [addressComponents] = results;

    const city = addressComponents.address_components.find(({ types }) => {
      return types.some(x => x == 'administrative_area_level_2');
    });
      console.log("city",city)
    if (!city) return { error: "Invalid latlng", code: 400 };

    const mainSelector = {};
    if (menuWorth == '$') {
      extend(mainSelector, {
        menuWorth: {
          [Sequelize.Op.between]: [0, 100]
        }
      });
    }    else if (menuWorth == '$$') {
      extend(mainSelector, {
        menuWorth: {
          [Sequelize.Op.between]: [100, 500]
        }
      });
    }
    else if (menuWorth == '$$$') {
      extend(mainSelector, {
        menuWorth: {
          [Sequelize.Op.between]: [500, 1500]
        }
      });
    }
    else if (menuWorth == '$$$$') {
      extend(mainSelector, {
        menuWorth: {
          [Sequelize.Op.gt]: 1500
        }
      });
    }

    if (type) {
      extend(mainSelector, { type });
    }

    const foodcarts = await FoodCart.findAll({
      where: {
        status: FOOD_CART_STATUS.ACTIVE,
        city: city.long_name,
        [Sequelize.Op.and]: [
          { latlng: { [Sequelize.Op.ne]: null } },
          { latlng: { [Sequelize.Op.ne]: '' } }
        ],
        ...mainSelector,
        [Sequelize.Op.or]: [
          { isOnline: FOOD_CART_ONLINE.ONLINE },
          { 'type': 'restaurant' }
        ]
      },
      attributes: [
        'id',
        'latlng'
      ]
    });


    const foodcartsNearby = [];
    const [userLat, userLng] = latlng.split(',');

    foodcarts.forEach((foodcart) => {
      if (!foodcart.latlng) return;
      const [foodcartLat, foodCartLng] = foodcart.latlng.split(',');

      let distance = getDistanceByLatlng({
        latA: userLat,
        lngA: userLng,
        latB: foodcartLat,
        lngB: foodCartLng
      });

      distance /= 1609.344; // 1 MILES = 1609.344 METTERS

      if (distance <= radius) {
        foodcartsNearby.push({
          ...foodcart.toJSON(),
          distance
        });
      }
    });

    const foodcartsNearbyIds = foodcartsNearby.map(({ id }) => id);

    const selector = {};
    if (cuisineId) {
      extend(selector, { '$FoodCartCuisines.CuisineId$': cuisineId });
    }

    // if (cuisineId) {
    //   extend(selector, { '$FoodCartCuisines.CuisineId$': cuisineId });
    // }
    FoodCart.hasMany(FoodCartLike, { foreignKey: 'FoodCartId' });
    FoodCartLike.belongsTo(FoodCart, { foreignKey: 'FoodCartId' });
    const { count, rows } = await FoodCart.findAndCountAll({
      where: {
        id: { [Sequelize.Op.in]: foodcartsNearbyIds },
        ...selector
      },
      include: [
        { model: Company },
        {
          model: BusinessHours,
          separate: true
        },
        {
          model: FoodCartImages,
          separate: true
        },
        {
          model: FoodCartCuisine,
          include: [Cuisine]
        },
        FoodCartLike
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null,
      distinct: true,
      subQuery: false,
    });


    // const getRrows = [];
    // let like = [];
    // rows.forEach((row) => {
    //   console.log(row.id);
    //   like = FoodCartLike.findOne({
    //     where: { FoodCartId: row.id }
    //   });


    //   getRrows.push({
    //     ...row.toJSON(),
    //     like: like
    //   });

    // });

    return { code: 200, data: { count, foodcarts: rows } }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getFoodcart;
