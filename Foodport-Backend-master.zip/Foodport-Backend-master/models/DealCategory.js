const model = (sequelize, DataType) => {
  const dealCategorySchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const DealCategory = sequelize.define('DealCategory', dealCategorySchema);
  DealCategory.associate = ({ Deal, Categorydeal }) => {
    DealCategory.belongsTo(Deal);
    DealCategory.belongsTo(Categorydeal, { foreignKey: 'CategorydealId' });
  }

  return DealCategory;
};

export default model;
