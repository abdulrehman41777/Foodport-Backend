const model = (sequelize, DataType) => {
  const dealMenuSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    quantity: {
      type: DataType.INTEGER(11),
      allowNull: true
    }
  }


  const DealMenu = sequelize.define('DealMenu', dealMenuSchema);
  DealMenu.associate = ({ Deal, Menu }) => {
    DealMenu.belongsTo(Deal);
    DealMenu.belongsTo(Menu);
  }

  return DealMenu;
};

export default model;
