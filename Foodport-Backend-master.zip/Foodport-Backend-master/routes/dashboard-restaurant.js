import express from 'express';
import { getViews, getReviewsState } from '../services/restaurant-dashboard';

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/restaurant-dashboard/{id}/view-stat:
 *   get:
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 * 
 *     parameters:
 *      - name: startDate
 *        in: query
 *        required: false
 * 
 *      - name: endDate
 *        in: query
 *        required: false
 * 
 *      - name: id
 *        in: path
 *        required: false
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:id/view-stat', (req, res) => {
  getViews({ ...req.query, ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/restaurant-dashboard/{id}/review-stat:
 *   get:
 *     description: get FoodCart
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     parameters:
 *      - name: startDate
 *        in: query
 *        required: false
 * 
 *      - name: endDate
 *        in: query
 *        required: false
 * 
 *      - name: id
 *        in: path
 *        required: false
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:id/review-stat', (req, res) => {
  getReviewsState({ ...req.query, ...req.params })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
