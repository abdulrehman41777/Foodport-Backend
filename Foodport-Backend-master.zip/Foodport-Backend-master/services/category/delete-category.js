import { Category, MenuCategory } from '../../models';

const deleteCategory = async ({ id }) => {
  try {
    await Category.destroy({
      where: { id }
    });
    await MenuCategory.destroy({
      where: { CategoryId: id }
    });

    return { code: 200, message: 'Category has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteCategory;
