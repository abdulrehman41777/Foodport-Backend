import moment from 'moment';
import { User, Token, Sequelize } from '../../models';
import { TOKEN_TYPE } from '../../constants/enums';
import { verifyInviteToken } from '../../utils/token';
const inviteVerify = async ({ token }) => {
  try {

    if (!token) throw new Error('Token required');

    const userToken = verifyInviteToken({ token: token });

    const userId = userToken.userId

    const user = await User.findByPk(userId);

    if (!user) throw new Error('Your token has been expired.');

    const tokenData = await Token.findOne({
      where: {
        token,
        UserId: user.id,
        type: TOKEN_TYPE.INVITE_TOKEN,
        expireAt: {
          [Sequelize.Op.gte]: moment().toDate()
        }
      }
    });

    if (!tokenData) throw new Error('Your token has been expired.');

    return { code: 200, email: user.email };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default inviteVerify;
