import { FoodCart, sequelize, FoodCartImages, FoodCartCuisine, BusinessHours } from '../../models';
import { FOOD_CART_IMAGES_TYPE } from '../../constants/enums';

const addFoodcart = async ({
  foodcartId,
  files,
  description,
  email,
  phone,
  latlng,
  type,
  city,
  name,
  cuisines,
  businessHours
}) => {
  let transaction;
  try {
    if (!cuisines) throw new Error ('Please select Cusines');
    cuisines = JSON.parse(cuisines);

    if (!businessHours) throw new Error('Please add Business Hours');
    businessHours = JSON.parse(businessHours);

    transaction = await sequelize.transaction({ autoCommit: false });
    const { cover, images } = files;

    await FoodCart.update(
      {
        name,
        type,
        description,
        email,
        phone,
        latlng,
        type,
        city,
      },
      {
        transaction,
        where: { id: foodcartId }
      }
    );

    let foodcartImages = []
    if (images && images.length) {
      foodcartImages = images.map(({ key }) => ({
        name: key,
        FoodCartId: foodcartId,
        type: FOOD_CART_IMAGES_TYPE.IMAGE
      }));
    }

    if (cover && cover.length) {
      const image = cover.pop();
      foodcartImages.push({
        name: image.key,
        FoodCartId: foodcartId,
        type: FOOD_CART_IMAGES_TYPE.COVER
      });
    }

    if (foodcartImages.length) {
      await FoodCartImages.bulkCreate(foodcartImages, { transaction });
    }

    const foodcartCuisines = cuisines.map((id) => ({
      FoodCartId: foodcartId,
      CuisineId: id
    }));

    if (foodcartCuisines && foodcartCuisines.length) {
      await FoodCartCuisine.destroy({
        transaction,
        where: { FoodCartId: foodcartId }
      });
      await FoodCartCuisine.bulkCreate(foodcartCuisines, { transaction });
    }

    const foodcartBusinessHours = businessHours.map(({ startTime, endTime, isActive, day }) => ({
      startTime,
      endTime,
      isActive,
      day,
      FoodCartId: foodcartId
    }));

    if (businessHours && businessHours.length) {
      await BusinessHours.destroy({
        transaction,
        where: { FoodCartId: foodcartId }
      });

      await BusinessHours.bulkCreate(foodcartBusinessHours, { transaction });
    }

    await transaction.commit();
    return { code: 200 };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default addFoodcart;
