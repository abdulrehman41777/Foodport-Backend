const model = (sequelize, DataType) => {
  const reviewSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    }
  }


  const Categorydeal = sequelize.define('Categorydeal', reviewSchema);
  Categorydeal.associate = ({ FoodCart, DealCategory }) => {
    Categorydeal.belongsTo(FoodCart);
    Categorydeal.hasMany(DealCategory, { onDelete: 'cascade' });
  }

  return Categorydeal;
};

export default model;
