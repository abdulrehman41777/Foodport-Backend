import AWS from 'aws-sdk';

AWS.config.credentials = new AWS.Credentials({
  accessKeyId: process.env.ACCESS_KEY,
  secretAccessKey: process.env.SECRET_ACCESS_KEY
});

AWS.config.update({ region: process.env.REGION });

export default AWS;
