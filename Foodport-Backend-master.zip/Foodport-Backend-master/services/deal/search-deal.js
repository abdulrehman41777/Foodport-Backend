import { extend } from 'lodash';
import { DealCategory, Deal, DealCuisine, Cuisine, Sequelize, DealImages, Category } from '../../models';

const searchDeal = async ({ serveIn, cuisineId }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (serveIn) {
      extend(selector, { serveIn });
    }

    if (cuisineId) {
      extend(selector, { '$DealCuisines.CuisineId$': { [Sequelize.Op.in]: JSON.parse(cuisineId) } });
    }

    const deal_rows = await Deal.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: DealCuisine
        },
        { model: DealImages }
      ]
      //offset: skip ? Number(skip) : null,
      // limit: limit ? Number(limit) : null
    });
    let madeArr = deal_rows.rows;//Object.entries(deal_rows)
    let deal_ids = madeArr.map(a => a.id);

    const selector2 = {};
    extend(selector2, { '$DealCategories.DealId$': { [Sequelize.Op.in]: deal_ids } });
    const cat_rows = await Category.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector2,
      include: [
        {
          model: DealCategory
        }
      ]
      //offset: skip ? Number(skip) : null,
      // limit: limit ? Number(limit) : null
    });
    const res_data = { "deals": deal_rows, "cats": cat_rows }
    return { code: 200, data: res_data };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default searchDeal;
