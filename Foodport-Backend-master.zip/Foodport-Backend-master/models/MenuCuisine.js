const model = (sequelize, DataType) => {
  const cuisinesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    }
  }


  const MenuCuisine = sequelize.define('MenuCuisine', cuisinesSchema);

  MenuCuisine.associate = ({ Menu, Cuisine }) => {
    MenuCuisine.belongsTo(Menu);
    MenuCuisine.belongsTo(Cuisine);
  }

  return MenuCuisine;
};

export default model;
