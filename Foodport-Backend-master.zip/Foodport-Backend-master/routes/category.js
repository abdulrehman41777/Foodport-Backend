import express from 'express';
import { saveCategory, getCategory, updateCategory, deleteCategory } from '../services/category';

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/category:
 *   post:
 *     tags:
 *     - Category
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               foodCartId:
 *                 type: number
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/', (req, res) => {
  saveCategory({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/category:
 *   get:
 *     tags:
 *     - Category
 *     produces:
 *       - application/json
 * 
 *     parameters:
 *       - name: foodcartId
 *         in: query
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getCategory({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/category:
 *   put:
 *     tags:
 *     - Category
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *                 required: true
 *               CategoryId:
 *                 type: string
 *                 required: true
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/', (req, res) => {
  updateCategory({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/category/{id}:
 *   delete:
 *     tags:
 *     - Category
 *     description: Delete Category by Category ID
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', (req, res) => {
  deleteCategory({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});


export default routers;
