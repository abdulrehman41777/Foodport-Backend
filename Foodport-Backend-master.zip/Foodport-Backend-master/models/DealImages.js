const model = (sequelize, DataType) => {
  const dealImagesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false
    },
    type: {
      type: DataType.INTEGER(1),
      allowNull: false,
    }
  }


  const DealImages = sequelize.define('DealImages', dealImagesSchema);
  DealImages.associate = ({ Deal }) => {
    DealImages.belongsTo(Deal);
  }

  return DealImages;
};

export default model;
