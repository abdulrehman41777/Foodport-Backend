import { Reviews, Sequelize, FoodCart } from '../../models';

const blockReview = async ({ id }) => {
  try {
    const review = await Reviews.findByPk(id);
    if (!review) throw new Error('Invalid id');


    review.status = (review.status == 1) ? 0 : 1;
    await review.save();
    return { code: 200 }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default blockReview;
