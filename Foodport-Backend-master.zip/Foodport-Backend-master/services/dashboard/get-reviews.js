import { extend } from 'lodash';
import moment from 'moment';

import { Reviews, FoodCart, Sequelize } from '../../models';
import { BUSINESS_TYPE } from '../../constants/enums';

const getViews = async ({ companyId, startDate, endDate, foodcartType = 'all' }) => {
  try {
    let foodcartStat = [];
    let restaurantStat = [];

    const selector = { '$FoodCart.CompanyId$': companyId };
    const dateRanges = [];

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }

    if (foodcartType == BUSINESS_TYPE.FOOD_CART || foodcartType == 'all') {
      foodcartStat = await Reviews.findAll({
        where: {
          '$FoodCart.type$': BUSINESS_TYPE.FOOD_CART,
          ...selector
        },
        attributes: [
          [Sequelize.fn('COUNT', 'Reviews.*'), 'total'],
          [Sequelize.col('Reviews.createdAt'), 'createdAt']
        ],
        include: [FoodCart],
        group: [Sequelize.fn('DAY', Sequelize.col('Reviews.createdAt'))]
      });
    }

    if (foodcartType == BUSINESS_TYPE.RESTAURANT || foodcartType == 'all') {
      restaurantStat = await Reviews.findAll({
        where: {
          '$FoodCart.type$': BUSINESS_TYPE.RESTAURANT,
          ...selector
        },
        attributes: [
          [Sequelize.fn('COUNT', 'Reviews.*'), 'total'],
          [Sequelize.col('Reviews.createdAt'), 'createdAt']
        ],
        include: [FoodCart],
        group: [Sequelize.fn('DAY', Sequelize.col('Reviews.createdAt'))]
      });
    }


    const graphStat = [];
    const end = moment(endDate);

    for (const start = moment(startDate); start <= end; start.add(1, 'day')) {
      const foodcart = foodcartStat.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == start.format('DD/MM/YY')
      });

      const restaurant = restaurantStat.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == start.format('DD/MM/YY')
      });

      let date = start.toDate();
      let foodcartCount = 0;
      let restaurantCount = 0;

      if (foodcart) {
        foodcartCount = foodcart.toJSON().total;
      }

      if (restaurant) {
        restaurantCount = restaurant.toJSON().total;
      }

      graphStat.push({ date, foodcartCount, restaurantCount });
    }



    //foodcartStates
    const currentDate = moment().format('DD/MM/YY');
    let todayViewRows = foodcartStat.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == currentDate
    });
    let todayViews = 0;
    if (todayViewRows) todayViews = todayViewRows.toJSON().total;


    let lastDayDate = moment();
    lastDayDate = lastDayDate.add(-1, 'day');
    let lastDayViewRows = foodcartStat.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == lastDayDate.format('DD/MM/YY')
    });
    let lastDayViews = 0;
    if (lastDayViewRows) lastDayViews = lastDayViewRows.toJSON().total;


    let lastWeekViews = 0;
    let lastWeekDate = moment();
    lastWeekDate = lastWeekDate.add(-7, 'day');
    const end_date = moment();
    for (const start_date = lastWeekDate; start_date <= end_date; start_date.add(1, 'day')) {
      let lastWeekViewRows = foodcartStat.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == lastWeekDate.format('DD/MM/YY')
      });
      if (lastWeekViewRows) lastWeekViews += lastWeekViewRows.toJSON().total;
    }
    const foodcartStates = [{ todayViews, lastDayViews, lastWeekViews }];
    //foodcartStates


    //restaurantStat

    todayViewRows = restaurantStat.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == currentDate
    });
    todayViews = 0;
    if (todayViewRows) todayViews = todayViewRows.toJSON().total;


    lastDayViewRows = restaurantStat.find(({ createdAt }) => {
      return moment(createdAt).startOf('day').format('DD/MM/YY') == lastDayDate.format('DD/MM/YY')
    });
    lastDayViews = 0;
    if (lastDayViewRows) lastDayViews = lastDayViewRows.toJSON().total;


    lastWeekViews = 0;
    for (const start_date = lastWeekDate; start_date <= end_date; start_date.add(1, 'day')) {
      const lastWeekViewRows = foodcartStat.find(({ createdAt }) => {
        return moment(createdAt).startOf('day').format('DD/MM/YY') == lastWeekDate.format('DD/MM/YY')
      });
      if (lastWeekViewRows) lastWeekViews += lastWeekViewRows.toJSON().total;
    }
    const restaurantStates = [{ todayViews, lastDayViews, lastWeekViews }];
    //restaurantStat


    return { code: 200, data: graphStat, foodcartStates, restaurantStates }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getViews;
