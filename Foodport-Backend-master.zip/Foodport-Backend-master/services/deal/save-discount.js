import { DealDiscount, sequelize, Sequelize } from '../../models';

const saveDiscount = async ({ deals }) => {
  let transaction;
  try {

    transaction = await sequelize.transaction({ autoCommit: false });


    const dealDescount = deals.map((obj) => ({
      DealId: obj.id,
      discount: obj.discount,
      price: obj.price,
      discounted_price: obj.price - ((obj.discount * obj.price) / 100)
    }));

    await DealDiscount.bulkCreate(dealDescount,
      {
        updateOnDuplicate: ["DealId", "discount", "price", "discounted_price"]
      },
      { transaction }
    );


    await transaction.commit();
    transaction = null;


    return { code: 200 };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default saveDiscount;
