import moment from 'moment';

import { Views, Sequelize, FoodCart } from '../../models';
import { PAGE_VIEWS_TYPE } from '../../constants/enums';

const updateViews = async (req, res, next) => {
  const { id } = req.params;
  const ip = req.connection.remoteAddress;

  const lastView = await Views.findOne({
    where: {
      lastVisited: {
        [Sequelize.Op.gt]: moment().subtract(10, 'minutes').toDate(),
      },
      foodcartId: id,
      ip,
      page: PAGE_VIEWS_TYPE.FOOD_CART_DETAIL
    }
  });

  if (lastView) return next();

  await Views.create({
    page: PAGE_VIEWS_TYPE.FOOD_CART_DETAIL,
    ip,
    lastVisited: moment().toDate(),
    foodcartId: id
  });

  await FoodCart.increment(
    { views: +1 },
    { where: { id } }
  );
  next();
}

export default updateViews;
