import { extend } from 'lodash';
import { MenuCategory, Menu, MenuCuisine, Cuisine, Sequelize, MenuImages, Category, MenuDiscount } from '../../models';

const getMenu = async ({ serveIn, cuisineId, categoryId, startDate, endDate, skip, limit, foodcartId, keyword }) => {
  try {
    const selector = {};
    const dateRanges = [];

    if (serveIn) {
      extend(selector, { serveIn });
    }

    if (cuisineId) {
      extend(selector, { '$MenuCuisines.CuisineId$': cuisineId });
    }

    if (categoryId) {
      extend(selector, { '$MenuCategories.CategoryId$': categoryId });
    }

    if (foodcartId) {
      extend(selector, { FoodCartId: foodcartId });
    }

    if (startDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.gt]: startDate
        }
      });
    }

    if (endDate) {
      dateRanges.push({
        createdAt: {
          [Sequelize.Op.lt]: endDate
        }
      });
    }

    if (dateRanges.length) {
      extend(selector, { [Sequelize.Op.and]: dateRanges });
    }

    if (keyword) {
      extend(selector, {
        name: { [Sequelize.Op.substring]: keyword }
      });
    }

    const menus = await Menu.findAndCountAll({
      distance: true,
      subQuery: false,
      where: selector,
      include: [
        {
          model: MenuCuisine,
          include: [Cuisine]
        },
        {
          model: MenuCategory
        },
        {
          model: MenuImages
        },
        { model: MenuDiscount }
      ],
      offset: skip ? Number(skip) : null,
      limit: limit ? Number(limit) : null
    });

    return { code: 200, data: menus };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getMenu;
