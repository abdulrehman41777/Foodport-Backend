import { Cuisine, FoodCartCuisine } from '../../models';

const deleteCuisine = async ({ id }) => {
  try {
    await Cuisine.destroy({
      where: { id }
    });

    await FoodCartCuisine.destroy({
      where: { CuisineId: id }
    });

    await MenuCuisine.destroy({
      where: { CuisineId: id }
    });

    await DealCuisine.destroy({
      where: { CuisineId: id }
    });

    return { code: 200, message: 'Cuisine has been deleted successfully' }
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default deleteCuisine;
