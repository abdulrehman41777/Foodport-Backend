import { Deal, DealMenu, DealCategory, DealCuisine, DealImages, sequelize, FoodCart, Sequelize, DealDiscount } from '../../models';
import { DEAL_IMAGES_TYPE, DEAL_STATUS } from '../../constants/enums';

const updateDeal = async ({ dealId, menus, categoryIds, cuisineIds, foodCartId, name, description, serveIn, price, discount, files }) => {
  let transaction;
  try {


    transaction = await sequelize.transaction({ autoCommit: false });
    // UPDATE DEAL
    await Deal.update(
      {
        name,
        description,
        price,
        serveIn,
        FoodCartId: foodCartId,
        status: DEAL_STATUS.ACTIVE
      },
      {
        transaction,
        where: { id: dealId }
      }
    );

    //Discount 
    if (discount) {
      await DealDiscount.upsert(
        {
          DealId: dealId,
          discount: discount,
          price: price,
          discounted_price: price - ((discount * price) / 100)
        },
        { transaction }
      );
    }

    // DEAL IMAGES
    const { cover, images } = files;
    let dealImages = []
    if (images && images.length) {
      dealImages = images.map(({ key }) => ({
        name: key,
        DealId: dealId,
        type: DEAL_IMAGES_TYPE.IMAGE
      }));
    }

    // DEAL COVER IMAGE
    if (cover && cover.length) {
      const image = cover.pop();
      dealImages.push({
        name: image.key,
        DealId: dealId,
        type: DEAL_IMAGES_TYPE.COVER
      });
    }

    if (dealImages.length) {
      await DealImages.destroy({
        transaction,
        where: { DealId: dealId }
      });
      await DealImages.bulkCreate(dealImages, { transaction });
    }


    //DEAL MENUS 
    if (menus) {
      const menusObj = JSON.parse("[" + menus + "]");
      const dealMenus = menusObj.map((obj) => ({
        DealId: dealId,
        MenuId: obj.id,
        quantity: obj.quantity,
      }));


      if (dealMenus && dealMenus.length) {
        await DealMenu.destroy({
          transaction,
          where: { DealId: dealId }
        });

        await DealMenu.bulkCreate(dealMenus, { transaction });
      }
    }

    // DEAL CATEGORIES
    if (categoryIds) {
      categoryIds = categoryIds.split(',');
      const dealCategories = categoryIds.map((id) => ({
        DealId: dealId,
        CategorydealId: id
      }));


      if (dealCategories && dealCategories.length) {
        await DealCategory.destroy({
          transaction,
          where: { DealId: dealId }
        });

        await DealCategory.bulkCreate(dealCategories, { transaction });
      }
    }


    // DEAL cuisine
    if (cuisineIds) {
      cuisineIds = cuisineIds.split(',');
      const dealCuisine = cuisineIds.map((id) => ({
        DealId: dealId,
        CuisineId: id
      }));


      if (dealCuisine && dealCuisine.length) {
        await DealCuisine.destroy({
          transaction,
          where: { DealId: dealId }
        });

        await DealCuisine.bulkCreate(dealCuisine, { transaction });
      }
    }

    await transaction.commit();
    transaction = null;

    // TOTAL MANU AND SUM OF ITS PRICE
    // const dealStats = await Deal.findOne({
    //   where: {
    //     FoodCartId: foodcartId
    //   },
    //   attributes: [
    //     [Sequelize.fn('ROUND', Sequelize.fn('AVG', Sequelize.col('price')), 1), 'dealWorth']
    //   ],
    //   raw: true
    // });

    // // UPDATE DEAL WORTH IN FOODCART
    // await FoodCart.update(
    //   { dealWorth: dealStats.dealWorth },
    //   {
    //     transaction,
    //     where: { id: foodcartId }
    //   }
    // );

    return { code: 201 };
  }
  catch (error) {
    transaction && await transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default updateDeal;
