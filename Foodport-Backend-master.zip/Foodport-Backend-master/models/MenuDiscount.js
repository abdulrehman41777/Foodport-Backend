const model = (sequelize, DataType) => {
  const menuDiscountSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    discount: {
      type: DataType.FLOAT,
      allowNull: true
    },
    price: {
      type: DataType.INTEGER(11),
      allowNull: true
    },
    discounted_price: {
      type: DataType.INTEGER(11),
      allowNull: true
    }
  }


  const MenuDiscount = sequelize.define('MenuDiscount', menuDiscountSchema);
  MenuDiscount.associate = ({ Menu }) => {
    MenuDiscount.belongsTo(Menu);
  }

  return MenuDiscount;
};

export default model;
