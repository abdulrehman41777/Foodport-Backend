import express from 'express';
import { signup, login, resendEmailToken, verifyEmailToken, sendEmailOtp, verifyEmailOtp, resetPassword } from '../services/auth';
import authenticate from '../middlewares/routeMiddlewares/auth';
const { body, validationResult } = require('express-validator');

const routers = express.Router();

/**
 * @swagger
 *
 * /api/v1/auth/signup:
 *   post:
 *     tags:
 *     - Auth
 *     description: signup to application
 *     produces:
 *       - application/json
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             firstName:
 *               type: string
 *               required: true
 * 
 *             lastName:
 *               type: string
 *               required: true
 *       
 *             businessName:
 *               description: Bussiness name if user signup as business.
 *               type: string
 *               required: true
 *       
 *             email:
 *               description: User valid email address to login.
 *               type: string
 *       
 *             phone:
 *               required: false
 *               type: string
 *       
 *             password:
 *               description: password to login.
 *               type: string
 *       
 *             address:
 *               description: Postcode | City
 *               type: string
 *       
 *             dob:
 *               description: Date of birth
 *               type: string
 *               format: date-time
 *       
 *             userType:
 *               type: string
 *               enum:
 *                - client
 *                - business
 * 
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/signup').post((req, res) => {
  signup({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/auth/login:
 *   post:
 *     tags:
 *     - Auth
 *     description: Login to the application
 *     operationId: findPetsByStatus
 *     produces:
 *       - application/json
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             email:
 *               type: string
 *               required: true
 *            
 *             password:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.route('/login').post((req, res) => {
  login({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/auth/resend-email-token:
 *   post:
 *     tags:
 *     - Auth
 *     description: Login to the application
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: login
 */
routers.post('/resend-email-token', authenticate, (req, res) => {
  const { user } = req;
  resendEmailToken({ userId: user.id })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/auth/verify-email-token:
 *   post:
 *     tags:
 *     - Auth
 *     description: Login to the application
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 * 
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             token:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.post('/verify-email-token', authenticate, (req, res) => {
  const { user } = req;
  verifyEmailToken({ userId: user.id, ...req.body })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/auth/send-email-otp:
 *   post:
 *     tags:
 *     - Auth
 *     description: Send email otp
 *     produces:
 *       - application/json
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             email:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.post('/send-email-otp',
  body('email').isEmail().not().isEmpty().trim().escape(),
  (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    sendEmailOtp({ ...req.body })
      .then((data) => res.status(data.code).json(data));
  });



/**
 * @swagger
 *
 * /api/v1/auth/verify-email-otp:
 *   post:
 *     tags:
 *     - Auth
 *     description: Verify email otp
 *     produces:
 *       - application/json
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             userId:
 *               type: integer
 *               required: true
 *             token:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.post('/verify-email-otp',
  body('token').not().isEmpty().trim().escape(),
  (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    verifyEmailOtp({ ...req.body })
      .then((data) => res.status(data.code).json(data));
  });


/**
 * @swagger
 *
 * /api/v1/auth/reset-password:
 *   post:
 *     tags: 
 *     - Auth
 *     description: Reset Password
 *     produces:
 *       - application/json
 *     requestBody:
 *      content:
 *        application/json:
 *          schema:
 *            properties:
 *             password:
 *               type: string
 *               required: true
 *             confirmPassword:
 *               type: string
 *               required: true
 *             userId:
 *               type: integer
 *               required: true
 *             token:
 *               type: string
 *               required: true
 *     responses:
 *       200:
 *         description: login
 */
routers.post('/reset-password', (req, res) => {
  resetPassword({ ...req.body })
    .then((data) => res.status(data.code).json(data));
});


export default routers;
