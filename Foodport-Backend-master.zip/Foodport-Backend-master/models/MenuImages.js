const model = (sequelize, DataType) => {
  const menuImagesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false
    },
    type: {
      type: DataType.INTEGER(1),
      allowNull: false,
    }
  }


  const MenuImages = sequelize.define('MenuImages', menuImagesSchema);
  MenuImages.associate = ({ Menu }) => {
    MenuImages.belongsTo(Menu);
  }

  return MenuImages;
};

export default model;
