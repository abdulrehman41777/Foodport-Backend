import { Category } from '../../models';

const saveCategory = async ({ foodCartId, name }) => {
  try {
    const category = await Category.create({
      name,
      FoodCartId: foodCartId
    });

    return { code: 201, data: category };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default saveCategory;
