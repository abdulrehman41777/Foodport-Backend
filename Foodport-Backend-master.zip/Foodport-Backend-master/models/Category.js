const model = (sequelize, DataType) => {
  const reviewSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.STRING,
      allowNull: false,
    }
  }


  const Category = sequelize.define('Category', reviewSchema);
  Category.associate = ({ FoodCart, MenuCategory }) => {
    Category.belongsTo(FoodCart);
    Category.hasMany(MenuCategory, { onDelete: 'cascade' });
  }

  return Category;
};

export default model;
