
const model = (sequelize, DataType) => {
  const roleResourcesSchema = {
    id: {
      type: DataType.INTEGER(11),
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataType.ENUM,
      values: ['company', 'foodcart', 'menu', 'user', '*']
    },
    resourceId: {
      type: DataType.INTEGER,
      allowNull: true,
    },
    resourceType: {
      type: DataType.STRING,
      allowNull: true
    }
  }

  const RoleResource = sequelize.define('RoleResource', roleResourcesSchema);

  RoleResource.associate = ({ Role, Grants }) => {
    RoleResource.belongsTo(Role);
    RoleResource.hasMany(Grants, { onDelete: 'cascade' });
  }

  return RoleResource;
};

export default model;
