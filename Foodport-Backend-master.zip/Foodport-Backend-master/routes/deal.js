import express from 'express';
import { saveDeal, getDeal, deleteDeal, updateDeal, getDealById, toggleDealActive, getFoodcartDeal, saveDiscount } from '../services/deal';
import authenticate from '../middlewares/routeMiddlewares/auth';
import { uploadDealImage } from '../utils/multer';
const { body, check, validationResult } = require('express-validator');

const routers = express.Router();
/**
 * @swagger
 *
 * /api/v1/deal:
 *   post:
 *     tags:
 *     - Deal
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *               cover:
 *                description: ''
 *                type: file
 *                format: binary
 *               images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary        
 *               name:
 *                 type: string
 *                 required: true
 * 
 *               description:
 *                 type: string
 *                 required: true
 * 
 *               foodCartId:
 *                 type: number
 *                 required: true
 * 
 *               price:
 *                 type: number
 *                 required: true
 * 
 *               discount:
 *                 type: number
 *                 required: true
 * 
 *               categoryIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 * 
 *               cuisineIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 * 
 *               menus:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                     quantity:
 *                       type: integer
 *
 *               serveIn:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - break-fast
 *                 - lunch
 *                 - dinner
 *
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/',
  // body('name').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // body('description').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // body('foodCartId').isNumeric().withMessage('Value must be numeric').exists({ checkFalsy: true }).withMessage('Value cannot be empty  0 false null'),
  // body('price').isNumeric().withMessage('Value must be numeric').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // body('deals').isArray().withMessage('Value must be an array').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // body('categoryIds').isArray().withMessage('Value must be an array').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // body('cuisineIds').isArray().withMessage('Value must be an array').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  // body('serveIn').exists({ checkFalsy: true }).withMessage('Value cannot be empty 0 false null'),
  [authenticate, uploadDealImage],
  (req, res) => {

    // const errors = validationResult(req);
    // if (!errors.isEmpty()) {
    //   return res.status(400).json({ error: errors.array({ onlyFirstError: true }) });
    // }

    saveDeal({ ...req.body, files: req.files })
      .then((data) => res.status(data.code).json(data));
  });


/**
* @swagger
*
* /api/v1/deal/discount-create-update:
*   post:
*     tags:
*     - Deal
*     produces:
*       - application/json
*     security:
*       - bearerAuth: []
*     requestBody:
*       content:
*         application/json:
*           schema:
*             properties:
*               deals:
*                 type: array
*                 required: true
*                 items:
*                   type: object
*                   properties:
*                     id:
*                       type: integer
*                     price:
*                       type: integer
*                     discount:
*                       type: number
*
*     responses:
*       200:
*         description: null
*/

routers.post('/discount-create-update',
  [authenticate],
  (req, res) => {

    // const errors = validationResult(req);
    // if (!errors.isEmpty()) {
    //   return res.status(400).json({ error: errors.array({ onlyFirstError: true }) });
    // }

    saveDiscount({ ...req.body })
      .then((data) => res.status(data.code).json(data));
  });




/**
 * @swagger
 *
 * /api/v1/deal:
 *   get:
 *     tags:
 *     - Deal
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: dealId
 *        in: query
 * 
 *      - name: cuisineId
 *        in: query
 *    
 *      - name: categoryId
 *        in: query
 * 
 *      - name: serveIn
 *        in: query
 * 
 *      - name: startDate
 *        in: query
 * 
 *      - name: endDate
 *        in: query
 * 
 *      - name: foodcartId
 *        in: query
 * 
 *      - name: skip
 *        in: query
 * 
 *      - name: limit
 *        in: query
 * 
 *      - name: keyword
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/', (req, res) => {
  getDeal({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/deal/get_foodcart_deal:
 *   get:
 *     tags:
 *     - Deal
 *     produces:
 *       - application/json
 *     parameters:
 *      - name: foodcartId
 *        in: query
 * 
 *      - name: serveIn
 *        in: query
 *
 *      - name: cuisineId
 *        in: query
 * 
 *      - name: skip
 *        in: query
 * 
 *      - name: limit
 *        in: query
 * 
 *      - name: keyword
 *        in: query
 *         
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/get_foodcart_deal', (req, res) => {
  getFoodcartDeal({ ...req.query })
    .then((data) => res.status(data.code).json(data));
});


/**
 * @swagger
 *
 * /api/v1/deal/{id}:
 *   delete:
 *     tags:
 *     - Deal
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.delete('/:id', authenticate, (req, res) => {
  deleteDeal({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/deal/update:
 *   post:
 *     tags:
 *     - Deal
 *     consumes:
 *      - multipart/form-data
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *               cover:
 *                description: ''
 *                type: file
 *                format: binary
 *               images:
 *                description: The list of files
 *                type: array
 *                items:
 *                  type: file
 *                  format: binary
 *
 *               dealId:
 *                 type: number
 *                 required: true
 * 
 *               name:
 *                 type: string
 *                 required: true
 *
 *               description:
 *                 type: string
 *                 required: true
 *
 *               foodCartId:
 *                 type: number
 *                 required: true
 *
 *               price:
 *                 type: number
 *                 required: true
 *
 *               discount:
 *                 type: number
 *                 required: true
 *
 *               menus:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                     quantity:
 *                       type: integer
 *
 *               categoryIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 *
 *               cuisineIds:
 *                 type: array
 *                 required: true
 *                 items:
 *                   type: integer
 *
 *               serveIn:
 *                 type: string
 *                 required: true
 *                 enum:
 *                 - break-fast
 *                 - lunch
 *                 - dinner
 *
 *     responses:
 *       200:
 *         description: null
 */
routers.post('/update', [authenticate, uploadDealImage], (req, res) => {
  updateDeal({ ...req.body, files: req.files })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/deal/{id}/toggle-active:
 *   put:
 *     tags:
 *     - Deal
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.put('/:id/toggle-active', authenticate, (req, res) => {
  toggleDealActive({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

/**
 * @swagger
 *
 * /api/v1/deal/{id}:
 *   get:
 *     tags:
 *     - Deal
 *     description: get FoodCart Details
 *     produces:
 *       - application/json
 *     security:
 *       - bearerAuth: [] 
 *     parameters:
 *      - name: id
 *        in: path
 *        required: true
 * 
 *     responses:
 *       200:
 *         description: null
 */
routers.get('/:id', [authenticate], (req, res) => {
  getDealById({ ...req.params })
    .then((data) => res.status(data.code).json(data));
});

export default routers;
