const swaggerJSDoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'FoodPort',
      version: '1.0.0',
    },
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'Bearer'
        }
      }
    }
  },
  apis: [
    './routes/auth.js',
    './routes/foodcart.js',
    './routes/reviews.js',
    './routes/cuisine.js',
    './routes/category.js',
    './routes/categorydeal.js',
    './routes/menu.js',
    './routes/searchmenu.js',
    './routes/dashboard.js',
    './routes/dashboard-restaurant.js',
    './routes/user.js',
    './routes/deal.js'
  ],
};

export default swaggerJSDoc(options);
