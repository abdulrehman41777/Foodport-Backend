import { extend } from 'lodash';
import { User, Sequelize } from '../../models';
import { USER_STATUS, USER_TYPE } from '../../constants/enums';

const getAllUsers = async ({ authUserType, skip, limit, keyword, status }) => {
    try {
        if (authUserType != USER_TYPE.SUPERADMIN) {
            return { error: 'Only super admin can access this end point.', code: 400 };
        }
        const selector = {};
        if (keyword) {
            selector[Sequelize.Op.or] = [
                { name: { [Sequelize.Op.substring]: keyword } },
                { serialNo: { [Sequelize.Op.substring]: keyword } }
            ];
        }

        if (status) {
            extend(selector, { status });
        } else {
            status = USER_STATUS.ACTIVE;
            extend(selector, { status });
        }

        const data = await User.findAndCountAll({
            distinct: true,
            where: { ...selector },
            offset: skip ? Number(skip) : null,
            limit: limit ? Number(limit) : null,
            attributes: {
                exclude: ['password']
            }
        });

        return { code: 200, data }
    }
    catch (error) {
        return { error: error.message, code: 400 };
    }
}

export default getAllUsers;
