import { Category } from '../../models';

const getCategory = async ({ category }) => {
  try {
    const categories = await Category.findAll({});

    return { code: 201, data: categories };
  }
  catch (error) {
    return { error: error.message, code: 400 };
  }
}

export default getCategory;
