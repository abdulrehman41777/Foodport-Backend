
import moment from 'moment';
import { FoodCart, User, Role, RoleResource, Grants, sequelize, Sequelize, Token } from '../../models';
import { USER_STATUS, TOKEN_TYPE } from '../../constants/enums';
import { getUserInviteToken } from '../../utils/token';
import { sendUserInvitation } from '../../utils/sendgrid';

const invite = async ({ firstName, lastName, email, foodcartId, companyId }) => {
  let transaction;
  try {


    const foodcart_exist = await FoodCart.findOne({
      where: { id: foodcartId, CompanyId: companyId }
    });

    if (!foodcart_exist) {
      return { code: 400, message: 'Foodcart Or Restaurant not exist or not registered in this company.' }
    }

    const user_exist = await User.findOne({
      where: { email: email }
    });

    if (user_exist) {

      const RoleId = user_exist.RoleId;
      const resourceType = foodcart_exist.type;

      const resource_exist = await RoleResource.findOne({
        where: { RoleId, resourceType }
      });

      if (resource_exist) {

        const tokenData = await Token.findOne({
          where: {
            UserId: user_exist.id,
            type: TOKEN_TYPE.INVITE_TOKEN,
            expireAt: {
              [Sequelize.Op.gte]: moment().toDate()
            }
          }
        });

        if (tokenData) throw new Error('This user already has invitation.');

        await Token.destroy({
          where: {
            UserId: user_exist.id,
            type: TOKEN_TYPE.INVITE_TOKEN
          }
        });


        const tokenExpireAt = moment().add(1, 'day');
        const token = getUserInviteToken({ userId: user_exist.id, expireAt: tokenExpireAt });

        await Token.create(
          {
            token,
            type: TOKEN_TYPE.INVITE_TOKEN,
            UserId: user_exist.id,
            expireAt: tokenExpireAt
          }
        );
        const redirectUrl = `${process.env.CLIENT_URL}/auth/invite/${token}`;

        await sendUserInvitation({
          to: user_exist.email,
          data: { redirectUrl }
        });

        return { code: 200, message: 'Invitation has been sent successfully' }
      } else {

        transaction = await sequelize.transaction({ autoCommit: false });

        const resourcesData = {
          name: resourceType,
          resourceId: foodcartId,
          resourceType: resourceType,
          RoleId: RoleId
        };

        const resources = await RoleResource.create(resourcesData, { transaction });

        let grantsData = [
          ...grantsData,
          { grantType: `view-${resourceType}-dashboard`, RoleResourceId: resources.id },
          { grantType: `add-${resourceType}`, RoleResourceId: resources.id },
          { grantType: `edit-${resourceType}`, RoleResourceId: resources.id },
          { grantType: `delete-${resourceType}`, RoleResourceId: resources.id },
          { grantType: `view-${resourceType}`, RoleResourceId: resources.id }
        ]

        await Grants.bulkCreate(grantsData, { transaction });

        await transaction.commit();
        return {
          code: 200, message: `User already exist so ${resourceType} grant successfully.`
        }

      }
    }


    const getResourceType = foodcart_exist.type;


    transaction = await sequelize.transaction({ autoCommit: false });

    const role = await Role.create({ name: 'Assistant' }, { transaction });

    const resourcesData = [
      {
        name: getResourceType,
        resourceId: foodcartId,
        resourceType: getResourceType,
        RoleId: role.id
      },
      {
        name: 'menu',
        resourceType: 'menu',
        RoleId: role.id
      }
    ];

    const resources = await RoleResource.bulkCreate(resourcesData, { transaction });

    let grantsData = [];
    resources.forEach(({ id, resourceType }) => {
      if (resourceType == 'menu') {
        grantsData.push({
          grantType: '*',
          RoleResourceId: id
        });
      }
      else {
        grantsData = [
          ...grantsData,
          { grantType: `view-${getResourceType}-dashboard`, RoleResourceId: id },
          { grantType: `add-${getResourceType}`, RoleResourceId: id },
          { grantType: `edit-${getResourceType}`, RoleResourceId: id },
          { grantType: `delete-${getResourceType}`, RoleResourceId: id },
          { grantType: `view-${getResourceType}`, RoleResourceId: id }
        ]
      }
    })

    await Grants.bulkCreate(grantsData, { transaction });

    const user = new User({
      firstName,
      lastName,
      email,
      status: USER_STATUS.INACTIVE,
      RoleId: role.id,
      CompanyId: companyId,
      userType: 'child'
    });

    await user.save({ transaction });

    const tokenExpireAt = moment().add(1, 'day');
    const token = getUserInviteToken({ userId: user.id, expireAt: tokenExpireAt });


    await Token.create(
      {
        token,
        type: TOKEN_TYPE.INVITE_TOKEN,
        UserId: user.id,
        expireAt: tokenExpireAt
      },
      { transaction }
    );

    const redirectUrl = `${process.env.CLIENT_URL}/auth/invite/${token}`;

    await sendUserInvitation({
      to: user.email,
      data: { redirectUrl }
    });

    await transaction.commit();

    return { code: 200, message: 'Invitation has been sent successfully' }
  }
  catch (error) {
    transaction && transaction.rollback();
    return { error: error.message, code: 400 };
  }
}

export default invite;
